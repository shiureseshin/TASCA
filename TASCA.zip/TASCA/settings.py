"""Public defaults; optional machine-specific overrides are never published."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCAL = ROOT / 'local_config.json'
CONFIG = json.loads(LOCAL.read_text(encoding='utf-8')) if LOCAL.exists() else {}


def model_path(name):
    return Path(os.environ.get('TASCA_MODEL_ROOT', CONFIG.get('model_root', ROOT / 'models'))) / name


def data_path(kind):
    return Path(os.environ.get('TASCA_'+kind.upper()+'_DATA', CONFIG.get(kind+'_data', ROOT/'datasets'/kind)))


def core_path(name):
    manifest = json.loads((ROOT/'datasets/core_manifest.json').read_text())
    return str(Path(CONFIG.get('core_datasets', {}).get(name, ROOT/'datasets/core'/manifest[name]['filename'])))


def independent_manifest():
    rows = json.loads((ROOT/'datasets/independent_manifest.json').read_text())
    return [dict(row, file=str(data_path('independent')/row['file'])) for row in rows]


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()
