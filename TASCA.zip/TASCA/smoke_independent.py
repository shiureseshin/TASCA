"""One real independent-validation case, with a second pass testing resume."""
import json
import sys
from settings import ROOT, sha256, model_path
sys.path.insert(0,str(ROOT/'engines/independent'))
import independent_validation as experiment
from data_protocol import build_tasks, load_datasets


def main():
    experiment.RESULTS=ROOT/'outputs/independent_smoke'
    experiment.RESULTS.mkdir(parents=True,exist_ok=True)
    tasks,audit=build_tasks(load_datasets())
    experiment.freeze_protocol(tasks,audit)
    store=experiment.Store()
    try:
        backend=experiment.Forecaster(store,sha256(model_path('chronos-2')/'model.safetensors'))
        experiment.run_case(tasks[0],24,0,backend,store)
        calls=backend.calls
        experiment.run_case(tasks[0],24,0,backend,store)
        assert backend.calls==calls
        result=dict(scope='one independent case, not full benchmark',new_model_calls=calls,
                    second_pass_new_calls=backend.calls-calls,case_rows=len(store.frame('cases')))
        (experiment.RESULTS/'smoke_report.json').write_text(json.dumps(result,indent=2))
        print(json.dumps(result,indent=2))
    finally:
        store.close()


if __name__=='__main__':
    main()
