"""Offline real-data model-interface smoke tests, not a full benchmark."""
import json
import sys
from pathlib import Path
import numpy as np
from settings import ROOT

sys.path.insert(0,str(ROOT/'engines/core'))
import corrected_benchmark as core


def main():
    core.OUT=ROOT/'outputs/smoke'
    core.OUT.mkdir(parents=True,exist_ok=True)
    store=core.Store()
    pair=core.Data().pair('ETTh1','ETTh2')
    window=core.Data().windows(pair,'original',24)[0]
    origin=window['origin']
    report=[]
    try:
        for name in ('chronos2','moirai2'):
            backend=core.Backend(name,store)
            for method,indices in core.contexts(pair,False).items():
                x=pair.values[origin-core.L:origin,indices].T
                prediction,key=backend.predict(x,24)
                assert prediction.shape==(24,) and np.isfinite(prediction).all()
                again,again_key=backend.predict(x,24)
                assert key==again_key
                np.testing.assert_array_equal(prediction,again)
                report.append(dict(model=name,context=method,channels=len(indices),finite=True,resume_cache_equal=True))
            del backend
    finally:
        store.close()
    (core.OUT/'smoke_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
