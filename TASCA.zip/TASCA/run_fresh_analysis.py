"""Additional manuscript analyses of newly completed core and extension outputs."""
import os
import subprocess
import sys
from settings import ROOT


if __name__=='__main__':
    script=ROOT/'engines/synchronized/analyze_cached_evidence.py'
    subprocess.run([sys.executable,str(script)],cwd=script.parent,env=dict(os.environ,PYTHONPATH=str(ROOT)),check=True)
