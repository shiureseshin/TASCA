"""Optional ONLINE preparation; inference scripts remain strictly offline."""
import hashlib
import os
import subprocess
import sys
import urllib.request
from pathlib import Path
from settings import ROOT, independent_manifest, sha256


def main():
    for row in independent_manifest():
        dest=Path(row['file'])
        if dest.exists():
            if sha256(dest)!=row['sha256']:
                raise ValueError('Existing data hash mismatch: '+dest.name)
            continue
        dest.parent.mkdir(parents=True,exist_ok=True)
        temporary=dest.with_suffix(dest.suffix+'.download')
        urllib.request.urlretrieve(row['url'],temporary)
        if sha256(temporary)!=row['sha256']:
            raise ValueError('Remote bytes differ from frozen data: '+dest.name)
        temporary.replace(dest)
        print('Verified '+dest.name,flush=True)
    subprocess.run([sys.executable,str(ROOT/'engines/synchronized/download_synchronized_data.py')],
                   env=dict(os.environ,PYTHONPATH=str(ROOT)),check=True)


if __name__=='__main__':
    main()
