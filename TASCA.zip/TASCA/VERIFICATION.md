# Verification scope

Packaging date: 2026-11-13. Tested with the existing Python 3.10 `freqrank_clean` environment and NVIDIA RTX 3060 Laptop GPU. This is a code-release validation, not a new scientific experiment.

| Check | Result |
|---|---|
| Core raw data | All 10 files located and matched against the original SHA-256 audit |
| Unit/protocol tests | 20 passed: 5 core, 9 independent, 6 synchronized |
| Archived core statistics | TASCA target-macro MSE 0.232170541619386; native 0.2603893558905769, regression passed |
| Offline model inference | Chronos-2 and Moirai-2, target/native/source inputs: all 6 checks passed |
| Prediction cache | Repeated predictions exactly equal |
| Independent inference | One real case, 48 new forecasts; repeated case produced zero new model calls; tensor/dataframe interface max difference 0 |
| LoRA training | One pair, all 3 contexts, 100 steps each; evaluation and summary completed; base-weight integrity assertion passed |
| Numerical figures | Four reference-data result figures exported to PDF/SVG/PNG; automatic text-bound checks passed |

Not performed in this packaging pass: a new full 22-pair/three-placement/multiple-horizon benchmark, the full independent or synchronized inference suite, all 66 LoRA fits, a fresh-environment dependency solve, or a full reproduction on another computer. `run_fresh_analysis.py` and `create_fresh_result_figures.py` require those complete new outputs and were not executed against a full new run. The complete source for these workflows is included; execution status must not be confused with source availability.

Raw data, weights, adapter files, caches, and local paths are excluded from the release archive. Source URLs and exact core hashes are documented, but conversion of all upstream core formats into the historical CSV bytes is not automated. A third-party user must obtain matching prepared files or document a new, separate dataset revision. This remains a limitation of exact external reproduction, not a reason to silently substitute files.

The source implementations and reference numerical tables are preserved from the frozen corrected studies. Migration changes path resolution, isolates workflows, adds launch-time provenance guards and exposes test/reproduction entry points. A parity test compares the independent selector with the corrected core selector over randomized losses and seven widths. This does not constitute a claim of statistical significance or new improvement.
