"""PyCharm Run: real-data preprocessing tests, syntax checks and table regression."""
import ast
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from settings import ROOT


def main():
    checks=[]
    for path in ROOT.rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    env=dict(os.environ,PYTHONPATH=str(ROOT))
    for rel in ('core/test_correction.py','independent/test_validation.py','synchronized/test_revision.py'):
        p=ROOT/'engines'/rel
        result=subprocess.run([sys.executable,str(p)],env=env,cwd=p.parent,text=True,capture_output=True)
        print(result.stdout+result.stderr,flush=True)
        checks.append(dict(test=rel,returncode=result.returncode,output=result.stdout+result.stderr))
    (ROOT/'outputs').mkdir(exist_ok=True)
    (ROOT/'outputs/verification.json').write_text(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),checks=checks),indent=2))
    if any(c['returncode'] for c in checks):
        raise RuntimeError('Some checks failed; inspect outputs/verification.json')
    subprocess.run([sys.executable,str(ROOT/'reproduce_tables.py')],check=True)
    print('All selected repository checks passed.')


if __name__=='__main__':
    main()
