"""Plot new full results only; never fall back to reference data."""
import json
import pandas as pd
from settings import ROOT, sha256
import create_result_figures as figures


def main():
    core_path=ROOT/'engines/core/corrected_results/case_results.csv'
    independent=ROOT/'engines/independent/results/frozen_tasca_v1'
    figures.SYNC_RESULTS=ROOT/'engines/synchronized/results/synchronized_v1'
    figures.CACHED_RESULTS=ROOT/'engines/synchronized/results/cached_analysis'
    figures.OUT=ROOT/'outputs/fresh_result_figures'
    figures.ASSETS=ROOT/'outputs/fresh_manuscript_figures'
    for p in (figures.OUT,figures.ASSETS):
        p.mkdir(parents=True,exist_ok=True)
    cases=pd.read_csv(core_path)
    core=cases[(cases.study=='core') & (cases.model=='chronos2') & (cases.horizon==24)]
    assert len(core[core.policy=='TASCA'])==66, 'Full core results required'
    with figures.plt.rc_context(figures.STYLE):
        figures.pair_figure(core)
        figures.component_figure(core,pd.read_csv(independent/'case_results.csv'))
        figures.external_figure(pd.read_csv(independent/'family_results.csv'),pd.read_csv(independent/'macro_results.csv'))
        figures.admission_figure()
    (figures.OUT/'manifest.json').write_text(json.dumps(dict(source='fresh runs only',core_sha256=sha256(core_path),outputs=figures.FILES),indent=2))
    print('Figures generated from fresh full outputs:',figures.OUT)


if __name__=='__main__':
    main()
