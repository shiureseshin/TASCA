REPS = {'original': 'frozen', 'phase_shifted': 'frozen', 'late_phase': 'frozen'}

def rank(frame, target, n=24):
    others = [c for c in frame if c != target]
    return [target] + list(frame[others].var().sort_values(ascending=False).index[:n-1])
