"""Corrected matched LoRA comparison. PyCharm/freqrank_clean, offline and resumable."""
import gc
import hashlib
import json
import os
from pathlib import Path
import time
import numpy as np
import pandas as pd
import torch
from corrected_benchmark import ROOT, OUT, MODEL, BASE, T, N, C, L, Data, atomic, canonical, choose

DEST = ROOT / "corrected_lora_results"


def main():
    if not (OUT/"completion.json").exists():
        raise RuntimeError("Run corrected_benchmark.py to completion first")
    from chronos import Chronos2Pipeline
    DEST.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    data=Data()
    protocol={"seed":20260711,"rank":8,"alpha":16,"steps":100,"learning_rate":1e-5,
              "train_windows":3,"validation_windows":1,"replication":"original","contexts":list(BASE),
              "preprocessing":"Same corrected inputs as frozen core; future labels originally missing are NaN during LoRA training and masked during scoring.",
              "comparison":"TASCA selected using four pre-test frozen windows; LoRA trains on first three and selects on fourth; no test tuning."}
    atomic(DEST/"protocol.json",json.dumps(protocol,indent=2))
    base=Chronos2Pipeline.from_pretrained(str(MODEL),device_map="cuda",local_files_only=True)
    initial_hash=hashlib.sha256(next(base.model.parameters()).detach().cpu().numpy().tobytes()).hexdigest()
    jobs=[]
    for target,source in data.pairs:
        p=data.pair(target,source)
        windows=data.windows(p,"original",24)
        cal=[w for w in windows if w["split"]=="calibration"]
        assert len(cal)==4 and cal[-1]["eligible"]
        assert max(w["origin"]+24 for w in cal[:3])<=cal[-1]["origin"]-L
        for method in BASE:
            job=f"{target}__{source}__{method}"
            path=DEST/"jobs"/(job+".json")
            if path.exists():
                jobs.append(json.loads(path.read_text(encoding="utf-8")))
                continue
            channels=[0] if method==T else list(range(p.native if method==N else p.values.shape[1]))
            training=[]
            for w in cal[:3]:
                origin=w["origin"]
                a=p.values[origin-L:origin+24,channels].copy()
                future_observed=p.observed[origin:origin+24,channels]
                a[L:][~future_observed]=np.nan
                training.append(a.T)
            torch.manual_seed(20260711)
            np.random.seed(20260711)
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            started=time.perf_counter()
            attempt=DEST/"adapters"/job
            attempt.mkdir(parents=True,exist_ok=True)
            print(time.strftime("[%H:%M:%S] ")+"Training "+job,flush=True)
            fitted=base.fit(inputs=training,prediction_length=24,validation_inputs=None,
                finetune_mode="lora",lora_config={"r":8,"lora_alpha":16,"lora_dropout":0.,
                  "target_modules":["self_attention.q","self_attention.v","self_attention.k","self_attention.o","output_patch_embedding.output_layer"]},
                context_length=L,learning_rate=1e-5,num_steps=100,batch_size=1,output_dir=attempt,
                min_past=L,finetuned_ckpt_name="adapter_final",logging_steps=100,
                seed=20260711,data_seed=20260711,disable_tqdm=True,remove_printer_callback=True)
            fitted.model.eval()
            train_time=time.perf_counter()-started
            median=list(fitted.quantiles).index(.5)
            forecasts=[]
            for w in [cal[-1]]+[w for w in windows if w["split"]=="test" and w["eligible"]]:
                origin=w["origin"]
                x=p.values[origin-L:origin,channels].T.astype(np.float32)
                with torch.inference_mode():
                    out=fitted.predict([x],prediction_length=24,context_length=L,batch_size=1,cross_learning=True)[0]
                pred=out[0,median].cpu().numpy().astype(float)
                truth=p.values[origin:origin+24,0].astype(float)
                mask=p.observed[origin:origin+24,0]
                mse=float(np.mean((pred[mask]-truth[mask])**2))
                assert np.isfinite(mse)
                forecasts.append({**w,"prediction":pred.tolist(),"truth":truth.tolist(),"mask":mask.tolist(),"mse":mse})
            trainable,total=fitted.model.get_nb_trainable_parameters()
            result={"pair":p.key,"target":target,"source":source,"method":method,"training_seconds":train_time,
                    "trainable":int(trainable),"parameters":int(total),"peak_allocated_gb":torch.cuda.max_memory_allocated()/2**30,
                    "forecasts":forecasts}
            atomic(path,canonical(result))
            jobs.append(result)
            print(time.strftime("[%H:%M:%S] ")+f"Completed {len(jobs)}/66: {job}",flush=True)
            del fitted
            gc.collect()
            torch.cuda.empty_cache()
    assert hashlib.sha256(next(base.model.parameters()).detach().cpu().numpy().tobytes()).hexdigest()==initial_hash
    frozen=pd.read_csv(OUT/"case_results.csv")
    frozen=frozen[(frozen.study=="core")&(frozen.model=="chronos2")&(frozen.replication=="original")]
    rows=[]
    for pair,g in pd.DataFrame(jobs).groupby("pair"):
        error={r.method:np.mean([f["mse"] for f in r.forecasts if f["split"]=="test"]) for r in g.itertuples()}
        validation={r.method:r.forecasts[0]["mse"] for r in g.itertuples()}
        selected=min(BASE,key=lambda m:(validation[m],m))
        fg=frozen[frozen.pair==pair].set_index("policy")
        tasca=fg.loc["TASCA","selected"]
        results={"frozen_TASCA":fg.loc["TASCA","mse"],"LoRA_TASCA_context":error[tasca],
                 "LoRA_validation_selected":error[selected],"LoRA_oracle":min(error.values())}
        results.update({"LoRA_"+m:error[m] for m in BASE})
        for policy,mse in results.items():
            rows.append({"pair":pair,"policy":policy,"mse":float(mse),"tasca_context":tasca,"lora_validation_context":selected})
    cases=pd.DataFrame(rows)
    atomic(DEST/"cases.csv",cases.to_csv(index=False))
    atomic(DEST/"summary.csv",cases.groupby("policy").mse.mean().reset_index().to_csv(index=False))
    p=cases.pivot(index="pair",columns="policy",values="mse")
    comparisons=[]
    for policy in p:
        if policy=="frozen_TASCA":continue
        differences=(p[policy]-p.frozen_TASCA).to_numpy()
        rng=np.random.default_rng(20260703)
        boot=differences[rng.integers(0,len(p),(10000,len(p)))].mean(axis=1)
        lo,hi=np.quantile(boot,[.025,.975])
        comparisons.append({"policy":policy,"difference_vs_frozen_TASCA":float(differences.mean()),"ci_low":float(lo),"ci_high":float(hi)})
    atomic(DEST/"comparisons.csv",pd.DataFrame(comparisons).to_csv(index=False))
    atomic(DEST/"completion.json",json.dumps({"complete":True,"jobs":len(jobs),"training_seconds":sum(j["training_seconds"] for j in jobs),
          "base_weights_unchanged":True,"peak_gpu_gb":max(j["peak_allocated_gb"] for j in jobs)},indent=2))
    print(cases.groupby("policy").mse.mean().to_string(),flush=True)


if __name__=="__main__":
    main()
