"""Run directly in PyCharm to test the causal correction."""
import unittest
import numpy as np
import pandas as pd
from corrected_benchmark import Data, choose, score, T, N, C


class CorrectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=Data()

    def test_future_does_not_change_ranking_scaling_or_past(self):
        p=self.data.pair("electricity","traffic")
        selected=p.selected
        scales=p.scales
        prefix=p.values[:p.split].copy()
        d=Data()
        d.raw["electricity"].iloc[p.split:]=1e8
        d.raw["traffic"].iloc[p.split:]=-1e8
        q=d.pair("electricity","traffic")
        self.assertEqual(selected,q.selected)
        self.assertEqual(scales,q.scales)
        np.testing.assert_equal(prefix,q.values[:q.split])

    def test_leading_missing_values_not_backfilled(self):
        p=self.data.pair("PRSA","weather")
        self.assertTrue(np.isnan(p.values[:24,0]).all())
        self.assertFalse(p.observed[:24,0].any())
        self.assertTrue(np.isfinite(p.values[p.split:]).all())

    def test_windows_match_archive_and_calibration_precedes_test(self):
        for target,source in self.data.pairs:
            p=self.data.pair(target,source)
            for rep in ("original","phase_shifted","late_phase"):
                windows=self.data.windows(p,rep,24)
                self.assertTrue(any(w["eligible"] for w in windows if w["split"]=="calibration"))
                self.assertTrue(any(w["eligible"] for w in windows if w["split"]=="test"))

    def test_masks_do_not_score_imputed_labels(self):
        p=self.data.pair("PRSA","weather")
        w=[w for w in self.data.windows(p,"original",24) if w["start"]==1371][0]
        self.assertFalse(w["eligible"])
        observed=p.observed[w["origin"]:w["origin"]+24,0]
        self.assertEqual(int(observed.sum()),0)

    def test_guard_margin_dispersion(self):
        losses={T:[1.,1.],N:[.9,.9],C:[.89,.89]}
        self.assertEqual(choose(losses,7),N)
        self.assertEqual(choose(losses,32),T)
        losses[C]=[.8,.8]
        self.assertEqual(choose(losses,7),C)
        self.assertAlmostEqual(score([1,3]),2+.25*np.sqrt(2))


if __name__=="__main__":
    unittest.main(verbosity=2)
