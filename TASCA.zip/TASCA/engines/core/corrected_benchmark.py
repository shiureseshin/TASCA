"""Causal TASCA correction. PyCharm/freqrank_clean: open and Run, offline/resumable."""
from __future__ import annotations
import os
os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1")
import gc
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time
from types import SimpleNamespace
import numpy as np
import pandas as pd
from audit_preprocessing import REPS, rank

ROOT = Path(__file__).resolve().parent
from settings import core_path, model_path
PROJECT = ROOT.parent
OUT = ROOT / "corrected_results"
MODEL = model_path("chronos-2")
MOIRAI = model_path("moirai-2.0-r-small")
T, N, C = "target_univariate", "native_all", "cross_all"
BASE = (T, N, C)
L = 96


def canonical(obj):
    return json.dumps(obj, ensure_ascii=True, sort_keys=True, allow_nan=False)


def atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def log(message):
    OUT.mkdir(parents=True, exist_ok=True)
    line = time.strftime("[%Y-%m-%d %H:%M:%S] ") + message
    print(line, flush=True)
    with (OUT / "run.log").open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def archive_tables():
    d = pd.read_csv(ROOT / "windows.csv")
    d["target_path"] = d.target_dataset.map(core_path)
    return d


class Data:
    def __init__(self):
        self.archived = archive_tables()
        self.info = self.archived[["target_dataset", "target_path", "target_col"]].drop_duplicates().set_index("target_dataset")
        self.pairs = sorted(set(zip(self.archived.target_dataset, self.archived.source_dataset)))
        self.raw = {name: pd.read_csv(r.target_path, nrows=7000).select_dtypes(include="number").replace([np.inf, -np.inf], np.nan)
                    for name, r in self.info.iterrows()}
        self.cache = {}

    def pair(self, target, source, synchronized=False):
        key = (target, source, synchronized)
        if key in self.cache:
            return self.cache[key]
        a, b = self.raw[target].copy(), self.raw[source].copy()
        if synchronized:
            frames = []
            for name in (target, source):
                f = pd.read_csv(self.info.loc[name, "target_path"])
                dates = pd.to_datetime(f["date"], errors="raise")
                num = f.select_dtypes(include="number").replace([np.inf, -np.inf], np.nan)
                num.index = dates
                frames.append(num[~num.index.duplicated(keep="first")].sort_index())
            common = frames[0].index.intersection(frames[1].index).sort_values()[:7000]
            a, b = [f.loc[common].reset_index(drop=True) for f in frames]
        n = min(len(a), len(b))
        a, b = a.iloc[:n], b.iloc[:n]
        split = int(n*.7)
        arrays, observations, selected, scales = [], [], [], []
        for name, raw in ((target, a), (source, b)):
            filled = raw.ffill()
            train = filled.iloc[:split]
            usable = train.columns[train.notna().any()].tolist()
            target_col = self.info.loc[name, "target_col"]
            assert target_col in usable
            cols = rank(train[usable], target_col)
            x = filled[cols].to_numpy(dtype=np.float32)
            mean = np.nanmean(x[:split], axis=0, keepdims=True)
            std = np.nanstd(x[:split], axis=0, keepdims=True)
            std[std < 1e-6] = 1.0
            z = (x-mean)/std
            # A leading missing prefix stays missing; it never reaches evaluation histories.
            assert np.isfinite(z[split:]).all()
            arrays.append(z)
            observations.append(raw[cols].notna().to_numpy())
            selected.append(cols)
            scales.append({"mean": mean.tolist(), "std": std.tolist()})
        values = np.concatenate(arrays, axis=1)
        observed = np.concatenate(observations, axis=1)
        result = SimpleNamespace(target=target, source=source, key=f"{target}<-{source}",
            values=values, observed=observed, split=split, native=len(selected[0]),
            raw_width=len(a.columns), selected=selected, scales=scales, synchronized=synchronized)
        self.cache[key] = result
        return result

    def windows(self, pair, rep, horizon):
        count_cal, count_test = (4, 8) if rep == "original" else (6, 12)
        if pair.synchronized:
            count_cal, count_test = 3, 6
        count = count_cal + count_test
        last = len(pair.values) - pair.split - L - horizon
        if rep == "original":
            starts = np.linspace(0, last, count+2)[1:-1]
        elif rep == "phase_shifted":
            starts = (np.arange(count)+.5)/count * last
        else:
            starts = np.linspace(.15, .98, count) * last
        starts = [int(round(s)) for s in starts]
        if horizon == 24 and not pair.synchronized:
            ref = self.archived[(self.archived.target_dataset == pair.target) & (self.archived.source_dataset == pair.source)
                                 & (self.archived.replication == rep)]
            actual = sorted(ref.window_start.unique().astype(int))
            assert actual == starts, (pair.key, rep, starts, actual)
        out = []
        for i, start in enumerate(starts):
            origin = pair.split + start + L
            obs = pair.observed[origin:origin+horizon, 0]
            out.append({"split": "calibration" if i < count_cal else "test", "window": i if i < count_cal else i-count_cal,
                        "start": start, "origin": origin, "observed": int(obs.sum()), "eligible": bool(obs.any())})
        cal_end = max(w["origin"]+horizon for w in out if w["split"] == "calibration")
        test_origin = min(w["origin"] for w in out if w["split"] == "test")
        assert cal_end <= test_origin
        return out


def score(losses, penalty=.25):
    x = np.asarray(losses, dtype=float)
    assert len(x) and np.isfinite(x).all()
    mean = float(x.mean())
    sd = float(x.std(ddof=1)) if len(x)>1 else 0.
    return mean + penalty*sd if mean>1e-12 else mean


def choose(losses, width, penalty=.25, margin=.05, threshold=32, source=True):
    if width >= threshold:
        return T
    s = {m: score(losses[m], penalty) for m in BASE}
    non = min((T, N), key=lambda m:(s[m],m))
    best = min(BASE, key=lambda m:(s[m],m)) if source else non
    return non if best==C and (s[non]-s[C])/max(s[non],1e-12)<margin else best


def policies(losses, width):
    out = {m:m for m in BASE}
    out.update(TASCA=choose(losses,width), width_only=T if width>=32 else N,
               no_width_guard=choose(losses,width,threshold=float("inf")),
               no_dispersion=choose(losses,width,penalty=0),
               no_source_margin=choose(losses,width,margin=0),
               non_source_only=choose(losses,width,source=False),
               calibration_argmin=min(BASE,key=lambda m:(np.mean(losses[m]),m)))
    cv = {m:float(np.std(losses[m],ddof=1)/(np.mean(losses[m])+1e-12)) if len(losses[m])>1 else 0 for m in BASE}
    available = [m for m in BASE if cv[m]<=1] or list(BASE)
    out["calibration_cv"] = min(available,key=lambda m:(np.mean(losses[m]),m))
    for th in (24,48,64,96):
        out[f"threshold_{th}"] = choose(losses,width,threshold=th)
    for penalty in (.10,.20,.30,.50):
        out[f"penalty_{penalty:.2f}"] = choose(losses,width,penalty=penalty)
    for margin in (.02,.04,.06,.10):
        out[f"margin_{margin:.2f}"] = choose(losses,width,margin=margin)
    for k in (1,2,3,4):
        out[f"calibration_first_{k}"] = choose({m:losses[m][:k] for m in BASE},width)
    return out


class Store:
    def __init__(self):
        OUT.mkdir(parents=True,exist_ok=True)
        self.db = sqlite3.connect(OUT/"predictions.sqlite")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS predictions (key TEXT PRIMARY KEY,payload TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS windows (key TEXT PRIMARY KEY,payload TEXT)")
        self.db.commit()

    def get(self,table,key):
        r = self.db.execute(f"SELECT payload FROM {table} WHERE key=?",(key,)).fetchone()
        return json.loads(r[0]) if r else None

    def put(self,table,key,payload):
        self.db.execute(f"INSERT OR REPLACE INTO {table} VALUES (?,?)",(key,canonical(payload)))
        self.db.commit()

    def frame(self):
        return pd.DataFrame(json.loads(r[0]) for r in self.db.execute("SELECT payload FROM windows"))

    def close(self):
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.db.close()


class Backend:
    def __init__(self,name,store):
        import torch
        self.torch, self.name, self.store = torch,name,store
        torch.set_num_threads(4)
        torch.manual_seed(42)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        self.calls = 0
        self.cache = {}
        if name=="chronos2":
            from chronos import Chronos2Pipeline
            self.model = Chronos2Pipeline.from_pretrained(str(MODEL),device_map="cuda",local_files_only=True)
            self.model.model.eval()
            self.median = list(self.model.quantiles).index(.5)
        else:
            from uni2ts.model.moirai2 import Moirai2Module, Moirai2Forecast
            self.model = Moirai2Module.from_pretrained(str(MOIRAI),local_files_only=True).eval().to("cuda")
            self.forecast_cls = Moirai2Forecast
            self.median = min(range(len(self.model.quantile_levels)),key=lambda i:abs(float(self.model.quantile_levels[i])-.5))
        self.model_hash = hashlib.sha256(((MODEL if name=="chronos2" else MOIRAI)/"model.safetensors").read_bytes()).hexdigest()
        log("Loaded "+name)

    def predict(self,x,h):
        x = np.ascontiguousarray(x,dtype=np.float32)
        key = hashlib.sha256(canonical([self.name,self.model_hash,h,x.shape]).encode()+x.tobytes()).hexdigest()
        cached = self.store.get("predictions",key)
        if cached:
            return np.array(cached["prediction"]),key
        with self.torch.inference_mode():
            if self.name=="chronos2":
                out = self.model.predict([x],prediction_length=h,context_length=L,batch_size=1,cross_learning=True)[0]
                pred = out[0,self.median].cpu().numpy().astype(float)
            else:
                k = (x.shape[0],h)
                if k not in self.cache:
                    self.cache[k] = self.forecast_cls(prediction_length=h,target_dim=x.shape[0],
                        feat_dynamic_real_dim=0,past_feat_dynamic_real_dim=0,context_length=L,module=self.model).eval().to("cuda")
                xx = self.torch.as_tensor(x.T,device="cuda").unsqueeze(0)
                out = self.cache[k](xx,self.torch.ones_like(xx,dtype=self.torch.bool),self.torch.zeros((1,L),device="cuda",dtype=self.torch.bool))
                pp = out[0,self.median,:] if out.ndim==3 else out[0,self.median,:,0]
                pred = pp.cpu().numpy().astype(float)
        assert pred.shape==(h,) and np.isfinite(pred).all()
        self.store.put("predictions",key,{"prediction":pred.tolist(),"model":self.name,"model_hash":self.model_hash})
        self.calls += 1
        return pred,key


def contexts(pair, include_corr):
    native = list(range(pair.native))
    source = list(range(pair.native,pair.values.shape[1]))
    out = {T:[0],N:native,C:native+source}
    if include_corr:
        train = pair.values[:pair.split]
        scores = []
        for c in source:
            obs = np.isfinite(train[:,0]) & np.isfinite(train[:,c])
            a,b = train[obs,0],train[obs,c]
            v = abs(float(np.corrcoef(a,b)[0,1])) if np.std(a)>1e-8 and np.std(b)>1e-8 else 0
            scores.append((c,v if np.isfinite(v) else 0))
        indices = [i for i,_ in sorted(scores,key=lambda z:(-z[1],z[0]))[:4]]
        out["target_corr_source"] = [0]+indices
        out["native_corr_source"] = native+indices
    return out


def run_case(pair,rep,h,backend,store,study):
    windows = data.windows(pair,rep,h)
    channel_map = contexts(pair,study=="core" and backend.name=="chronos2")
    for w in windows:
        if not w["eligible"]:
            continue
        origin = w["origin"]
        truth = pair.values[origin:origin+h,0].astype(float)
        mask = pair.observed[origin:origin+h,0]
        for method in [*channel_map,"persistence"]:
            key = canonical([study,backend.name,pair.key,rep,h,w["split"],w["window"],method])
            if store.get("windows",key):
                continue
            if method=="persistence":
                pred,pk = np.full(h,pair.values[origin-1,0]),"persistence"
            else:
                pred,pk = backend.predict(pair.values[origin-L:origin,channel_map[method]].T,h)
            error = pred[mask]-truth[mask]
            row = {"key":key,"study":study,"model":backend.name,"pair":pair.key,"target":pair.target,
                   "source":pair.source,"replication":rep,"horizon":h,"method":method,"width":pair.raw_width,
                   **w,"prediction":pred.tolist(),"truth":truth.tolist(),"mask":mask.tolist(),"cache_key":pk,
                   "mse":float(np.mean(error**2)),"mae":float(np.mean(abs(error)))}
            store.put("windows",key,row)


def summarize(store):
    df = store.frame()
    compact = df.drop(columns=["prediction","truth","mask"])
    atomic(OUT/"window_metrics.csv",compact.to_csv(index=False))
    rows = []
    keys = ["study","model","horizon","pair","target","source","replication"]
    for key,g in df.groupby(keys,sort=True):
        cal = g[g["split"]=="calibration"]
        test = g[g["split"]=="test"]
        losses = {m:cal.loc[cal.method==m].sort_values("window").mse.to_list() for m in BASE}
        if not all(losses.values()) or set(test.method)<set(BASE):
            continue
        means = test.groupby("method")[["mse","mae"]].mean()
        choices = policies(losses,int(g.width.iloc[0]))
        choices.update({m:m for m in ("persistence","target_corr_source","native_corr_source") if m in means.index})
        choices["oracle"] = min(BASE,key=lambda m:means.loc[m,"mse"])
        for policy,selected in choices.items():
            rows.append(dict(zip(keys,key),policy=policy,selected=selected,mse=float(means.loc[selected,"mse"]),
                        mae=float(means.loc[selected,"mae"]),calibration_windows=len(losses[T]),test_windows=int((test.method==T).sum())))
    cases = pd.DataFrame(rows)
    atomic(OUT/"case_results.csv",cases.to_csv(index=False))
    summary = cases.groupby(["study","model","horizon","policy"])[["mse","mae"]].mean().reset_index()
    atomic(OUT/"summary.csv",summary.to_csv(index=False))
    comparisons = []
    for key,g in cases.groupby(["study","model","horizon"]):
        p = g.pivot(index=["pair","replication"],columns="policy",values="mse")
        for baseline in [N,T,C,"calibration_argmin","no_width_guard","width_only","non_source_only"]:
            differences = p.TASCA-p[baseline]
            # Replications remain together in each pair-cluster resample.
            blocks = differences.groupby(level="pair").mean().to_numpy()
            rng = np.random.default_rng(20260703)
            boot = blocks[rng.integers(0,len(blocks),(10000,len(blocks)))].mean(axis=1)
            lo,hi = np.quantile(boot,[.025,.975])
            comparisons.append(dict(zip(["study","model","horizon"],key),baseline=baseline,
                difference=float(differences.mean()),ci_low=float(lo),ci_high=float(hi),
                improvement_pct=float(100*(p[baseline].mean()-p.TASCA.mean())/p[baseline].mean())))
    atomic(OUT/"comparisons.csv",pd.DataFrame(comparisons).to_csv(index=False))
    log("Summary updated; windows="+str(len(df)))
    return cases


def freeze(data):
    metadata = []
    for t,s in data.pairs:
        p = data.pair(t,s)
        metadata.append({"pair":p.key,"selected":p.selected,"scales":p.scales,"split":p.split,
            "prepared_sha256":hashlib.sha256(np.nan_to_num(p.values,nan=123456).tobytes()+p.observed.tobytes()).hexdigest(),
            "windows24":{rep:data.windows(p,rep,24) for rep in REPS}})
    protocol = {"version":"causal_correction_v1","defaults":{"width":32,"penalty":.25,"margin":.05},
        "preprocessing":"Raw indices preserved; causal ffill only; ranking and scaling on first70%; leading NaN excluded from statistics; score observed labels only; all-missing horizons excluded identically for all candidates.",
        "scope":"Chronos2 core, horizons12/48/72, Moirai2 core, six synchronized directions, corrected original-replication 3+1-window LoRA; no outcome-driven parameter changes.",
        "horizon24_windows":"Exact archived placements; partial-label windows retained with their observed count; no replacement of all-missing windows.",
        "pairs":metadata}
    path = OUT/"frozen_protocol.json"
    if path.exists():
        assert json.loads(path.read_text(encoding="utf-8"))==protocol,"Protocol changed"
    else:
        atomic(path,json.dumps(protocol,indent=2))


def main():
    global data
    started = time.perf_counter()
    data = Data()
    OUT.mkdir(parents=True,exist_ok=True)
    freeze(data)
    store = Store()
    total_calls = 0
    for name in ("chronos2","moirai2"):
        backend = Backend(name,store)
        for rep in REPS:
            for t,s in data.pairs:
                run_case(data.pair(t,s),rep,24,backend,store,"core")
            log(f"{name} core {rep} complete; calls={backend.calls}")
            summarize(store)
        if name=="chronos2":
            for h in (12,48,72):
                for rep in REPS:
                    for t,s in data.pairs:
                        run_case(data.pair(t,s),rep,h,backend,store,"horizon")
                log(f"Chronos2 horizon{h} complete; calls={backend.calls}")
                summarize(store)
            for a,b in (("electricity","traffic"),("ETTh1","ETTh2"),("ETTh1","electricity")):
                for t,s in ((a,b),(b,a)):
                    run_case(data.pair(t,s,True),"original",24,backend,store,"timestamp")
            summarize(store)
        total_calls += backend.calls
        del backend
        gc.collect()
        import torch
        torch.cuda.empty_cache()
    integrity = store.db.execute("PRAGMA integrity_check").fetchone()[0]
    counts = store.db.execute("SELECT COUNT(*) FROM windows").fetchone()[0]
    store.close()
    atomic(OUT/"completion.json",json.dumps({"complete":True,"new_calls_this_run":total_calls,
        "logical_windows":counts,"sqlite_integrity":integrity,"seconds":time.perf_counter()-started},indent=2))
    log("All frozen corrected comparisons complete")


if __name__=="__main__":
    main()
