# Frozen revision protocol, 2026-10-19

This document and selector source are saved before inspecting new selector results
or running new model predictions. No parameter search or outcome-based replacement
of TASCA-v1 is permitted. The previously reported 22-pair benchmark and five
additional collections are now known evidence, not fresh test collections.

## Phase 2: cached evidence

Recompute all stored frozen-model window MSE/MAE from predictions and original-label
masks. Preserve the original pair-replication average. Additionally average sources
and placements inside each of the ten target datasets, then weight targets equally.
Use 20,000 paired target-bootstrap draws, seed 20261019. Report ten-target descriptive
win/tie/loss, median target-wise percent improvement and all leave-one-target-out
results. Group all ETT targets into one family as a further sensitivity analysis.
Report crossed target/source reweighting only as dependence sensitivity, not a cure
for all cross-role and historical dependencies. No iid test on 66 observations.

Primary comparisons: TASCA minus native-all, width-only, non-source-only, calibration
argmin, no-width-guard, no-dispersion, no-source-margin, and pairwise-guarded.
All variants use the same stored 3K forecasts; the two-context comparator needs only
2K and its smaller cost is reported. New selectors are exploratory on old data.

Pairwise-guarded: preserve raw-width 32 guard; choose native over target only when
mean(native-target)+0.25 SD(native-target)<0, then admit source when
mean(source-selected_non_source)+0.25 SD(difference)<-0.05 mean(selected_non_source).
Also show its unguarded version. Conservative non-source uses the same paired test
with a 5% native-versus-target margin and no raw-width guard. Soft-guard allows the
unguarded original choice at raw width>=32 only if its original score improves by
at least 5% over target-only. Retained-width>=32 under cap24 is intentionally shown
to be identical to no guard; it is not presented as a new effective-dimension method.

Admission diagnostics compare source test error both with native and the better
non-source TEST context, identifying the latter as retrospective. Separately measure
the realized policy effect relative to the deployable non-source rule. Assess
calibration-to-test gain correspondence, first/last 1--4 calibration windows,
leave-one-calibration-window-out decisions, lambda 0.10/0.25/0.50 and gamma
0.04/0.05/0.06, without choosing a new default from test outcomes.

## Phase 3: newly evaluated synchronous collections

Collections selected by metadata, not forecasting outcomes: UCI Air Quality (360),
Capital Bike Sharing (275), Seoul Bike Sharing Demand (560). They have published
timestamped observations and co-recorded weather. They are three collections from
different locations, not three unrelated application domains. Weather and target
are measurement groups within published collections, not separately assembled
geographic datasets. Pretraining overlap and actual reporting latency are unknown.

- Air Quality targets: CO(GT), C6H6(GT), NOx(GT), NO2(GT); native group these four;
  source T/RH/AH. NMHC is excluded a priori because of documented severe gaps and
  because four reference pollutant variables suffice; sensor proxies are excluded.
- Capital targets: cnt, casual, registered; native all three recorded demand series;
  source temp/atemp/hum/windspeed. Their additive dependence is disclosed. Only past
  counts are inputs, never future components of the target.
- Seoul target: Rented Bike Count; native group consists of the same single series;
  source the eight continuous weather measurements. Target-only and native coincide
  here; this is a two-distinct-context deployment case, reported explicitly.

Use the first 7,000 hourly grid rows, preserving gaps. Same-timestamp duplicate rows
are averaged; no interpolation or future fill. Training is first70%; remaining30%
is split into two chronological blocks. Each block contains six calibration and
ten test windows, length96, horizon24, nonoverlapping future intervals. Choose in
each fixed bin by observed-label count only (minimum18/24), then midpoint distance;
all histories must be finite after causal forward fill. Report all exclusions.
Source inputs have one additional hour of lag, assuming measurement availability
within that delay; published data do not establish real-time latency. No source
observation at or after the forecast origin is passed to the model.

Three prespecified source conditions: all weather; training-correlation top2 weather;
the same full weather delayed by an additional168 hours. The stale-source condition
is a dependence-weakening diagnostic, not a guaranteed irrelevant source: weekly and
seasonal relationships may persist. Main result is full weather; other conditions
are separate diagnostics, never pooled as independent samples or selected winners.
Each condition shares the same target windows. Ranking/scaling use training only.
Chronos-2 local checkpoint, float32, cross_learning=True, batch1, median quantile,
seed42; default raw-width32/lambda0.25/gamma0.05. No fitting or validation-based tuning.

Primary aggregate: within target, then within collection, then three-collection macro
MSE; MAE secondary. All eight targets and both blocks are intended (16 primary cases).
Collection-bootstrap intervals with only three collections are descriptive and weak;
report each collection and leave-one-collection-out as well. Positive source evidence
requires actual admission and lower subsequent error than both fixed non-source
contexts, plus policy improvement over non-source-only across all prespecified cases.
No minimum positive count is assumed. All failures remain. New low-width collections
cannot validate a new high-width guard: keep that risk open.

### Availability amendment before any model inference

The pre-inference unit test found an Air Quality bin with no eligible CO labels.
Rather than drop an entire target for one unavailable bin, omit that bin identically
for every method/condition, with no substitute window from another bin. Retain a
block only with at least3 calibration and6 test windows. All unavailable bins/blocks
are listed in the frozen manifest. Six/ten are nominal maxima. This amendment uses
only label availability; no prediction or forecasting error had been computed.

## Priority and resource estimate

Cached recomputation/statistics: CPU, minutes, zero model calls. New inference: at most
8 targets x 2 blocks x 16 windows x 3 conditions x 3 candidates = 2304 logical calls;
exact duplicate inputs cached, reducing physical calls. Prior measured benchmark
12258 calls/454s suggests minutes on this GPU; allow 5--30 minutes with loading/I/O.
Every prediction is transactionally saved; cancellation resumes by exact input hash.
Measure synchronized CUDA wall time and peak allocated memory, including channel counts.
Avoid additional LoRA/cross-model sweeps unless the new evidence identifies a need.

## Visual plan

F1 retain two-layer method with a clearer ordered decision block, symbolic score and
defaults outside main flow; F2 compact chronological protocol; both editable PPT and
vector export. F3 target-group separators and complete 22x3 cells. F4 explicit zero
source count and consistent labels, no invented uncertainty. F5 preserve failure
bars and four actual budget points. F6 only if calibration/test diagnostics add new
information; otherwise use the compact admitted-case table. Full numeric sources,
English captions, vector plots and raster previews accompany the paper.
