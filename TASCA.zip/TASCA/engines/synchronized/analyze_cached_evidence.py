"""PyCharm/freqrank_clean: Run. Read-only old caches; new results stay here."""
from pathlib import Path
import json
import sqlite3
import time
import numpy as np
import pandas as pd
from common import ROOT, T, N, C, BASE, choose, policies, score, digest, save_json, atomic, bootstrap_means

OLD = ROOT.parent / 'core'
OUT = ROOT / 'results/cached_analysis'


def audit_predictions():
    database = OLD / 'corrected_results/predictions.sqlite'
    metrics = pd.read_csv(OLD / 'corrected_results/window_metrics.csv').set_index('key')
    connection = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
    assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    maximum, count = 0., 0
    for payload, in connection.execute('SELECT payload FROM windows'):
        r = json.loads(payload)
        truth = np.asarray(r['truth'], dtype=float)
        predicted = np.asarray(r['prediction'], dtype=float)
        mask = np.asarray(r['mask'], dtype=bool)
        assert mask.any() and np.isfinite(truth[mask]).all() and np.isfinite(predicted).all()
        error = predicted[mask] - truth[mask]
        for field, value in [('mse', np.mean(error ** 2)), ('mae', np.mean(abs(error)))]:
            maximum = max(maximum, abs(value - r[field]), abs(value - metrics.loc[r['key'], field]))
        count += 1
    connection.close()
    assert count == len(metrics) == 23350 and maximum < 1e-12
    save_json(OUT / 'prediction_audit.json', {'windows': count, 'max_difference': maximum,
              'database_sha256': digest(database), 'read_only': True})


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    audit_predictions()
    windows = pd.read_csv(OLD / 'corrected_results/window_metrics.csv')
    windows = windows[(windows.study == 'core') & (windows.model == 'chronos2') & (windows.horizon == 24)]
    original = pd.read_csv(OLD / 'corrected_results/case_results.csv')
    original = original[(original.study == 'core') & (original.model == 'chronos2') & (original.horizon == 24)]
    rows, diagnostics, stability, sensitivities = [], [], [], []
    for (pair, rep), g in windows.groupby(['pair', 'replication']):
        cal = g[(g['split'] == 'calibration') & g.method.isin(BASE)].pivot(index='window', columns='method', values='mse').sort_index()
        assert not cal[list(BASE)].isna().any().any()
        losses = {m: cal[m].to_numpy() for m in BASE}
        test = g[g['split'] == 'test'].groupby('method')[['mse', 'mae']].mean()
        width = int(g.width.iloc[0])
        metadata = dict(pair=pair, replication=rep, target=g.target.iloc[0], source=g.source.iloc[0], raw_width=width)
        choices = policies(losses, width)
        for rule, selected in choices.items():
            rows.append(dict(metadata, policy=rule, selected=selected, mse=test.loc[selected, 'mse'], mae=test.loc[selected, 'mae']))
        ref = original[(original.pair == pair) & (original.replication == rep)]
        for r in ref.itertuples():
            if r.policy in choices:
                assert choices[r.policy] == r.selected
                assert abs(float(test.loc[r.selected, 'mse']) - r.mse) < 1e-12
        non = min((T, N), key=lambda m: (score(losses[m]), m))
        test_best = min((T, N), key=lambda m: (test.loc[m, 'mse'], m))
        cal_base = min(np.mean(losses[T]), np.mean(losses[N]))
        cal_gain = 100 * (1 - np.mean(losses[C]) / max(cal_base, 1e-12))
        test_gain = 100 * (1 - test.loc[C, 'mse'] / max(test.loc[test_best, 'mse'], 1e-12))
        diagnostics.append(dict(metadata, selected=choices['TASCA'], calibrated_non=non,
            calibration_gain_vs_best_non_pct=cal_gain, test_gain_vs_best_non_pct=test_gain,
            score_gain_pct=100 * (1 - score(losses[C]) / max(score(losses[non]), 1e-12)),
            test_best_non=test_best, source_mse=test.loc[C, 'mse'], native_mse=test.loc[N, 'mse'],
            target_mse=test.loc[T, 'mse'], best_non_mse=test.loc[test_best, 'mse'],
            source_vs_native_gain_pct=100 * (1 - test.loc[C, 'mse'] / test.loc[N, 'mse']),
            source_useful=bool(test.loc[C, 'mse'] < test.loc[test_best, 'mse'] - 1e-12),
            source_admitted=choices['TASCA'] == C,
            policy_vs_non_source=test.loc[choices['TASCA'], 'mse'] - test.loc[choices['non_source_only'], 'mse'],
            selection_regret=test.loc[choices['TASCA'], 'mse'] - test.loc[list(BASE), 'mse'].min()))
        for omitted in range(len(cal)):
            reduced = {m: np.delete(losses[m], omitted) for m in BASE}
            selected = choose(reduced, width)
            stability.append(dict(metadata, omitted=omitted, original=choices['TASCA'], selected=selected,
                                  changed=selected != choices['TASCA'], mse=test.loc[selected, 'mse']))
        settings = [('lambda', value) for value in (.10, .25, .50)] + [('gamma', value) for value in (.04, .05, .06)]
        for key, value in settings:
            selected = choose(losses, width, **({'penalty': value} if key == 'lambda' else {'margin': value}))
            sensitivities.append(dict(metadata, setting=key, value=value, selected=selected,
                mse=test.loc[selected, 'mse'], useful=bool(test.loc[C, 'mse'] < test.loc[test_best, 'mse'] - 1e-12)))
        for k in range(1, min(4, len(cal)) + 1):
            for position in ('first', 'last'):
                ll = {m: losses[m][:k] if position == 'first' else losses[m][-k:] for m in BASE}
                selected = choose(ll, width)
                sensitivities.append(dict(metadata, setting=position, value=k, selected=selected,
                    mse=test.loc[selected, 'mse'], useful=bool(test.loc[C, 'mse'] < test.loc[test_best, 'mse'] - 1e-12)))
    cases = pd.DataFrame(rows)
    assert len(cases[cases.policy == 'TASCA']) == 66 and cases.target.nunique() == 10
    cases.to_csv(OUT / 'selector_cases.csv', index=False)
    target = cases.groupby(['target', 'policy'])[['mse', 'mae']].mean().reset_index()
    target.to_csv(OUT / 'target_means.csv', index=False)
    comparisons, exclusions = [], []
    overall = cases.groupby('policy')[['mse', 'mae']].mean()
    macro = target.groupby('policy')[['mse', 'mae']].mean()
    overall.join(macro, lsuffix='_case', rsuffix='_target').to_csv(OUT / 'selector_summary.csv')
    pivot = cases.pivot(index=['target', 'source', 'pair', 'replication'], columns='policy', values='mse')
    tm = target.pivot(index='target', columns='policy', values='mse')
    for baseline in [N, T, C, 'width_only', 'non_source_only', 'calibration_argmin', 'no_width_guard',
                     'no_dispersion', 'no_source_margin', 'pairwise_guarded', 'pairwise_no_guard',
                     'conservative_non_source', 'soft_guard', 'retained_width_guard']:
        delta = tm.TASCA - tm[baseline]
        lo, hi = bootstrap_means(delta)
        pair_delta = (pivot.TASCA - pivot[baseline]).groupby(level='pair').mean()
        plo, phi = bootstrap_means(pair_delta, seed=20260703, draws=10000)
        family = target.copy()
        family['family'] = family.target.map(lambda s: 'ETT' if s.startswith('ETT') else s)
        fm = family.groupby(['family', 'policy']).mse.mean().unstack()
        flo, fhi = bootstrap_means(fm.TASCA - fm[baseline])
        comparisons.append(dict(baseline=baseline, case_mse_tasca=overall.loc['TASCA', 'mse'],
            case_mse_baseline=overall.loc[baseline, 'mse'], case_difference=float(pair_delta.mean()),
            pair_ci_low=plo, pair_ci_high=phi, target_mse_tasca=tm.TASCA.mean(),
            target_mse_baseline=tm[baseline].mean(), target_difference=delta.mean(),
            target_ci_low=lo, target_ci_high=hi, target_gain_pct=100*(1-tm.TASCA.mean()/tm[baseline].mean()),
            median_target_gain_pct=float((100*(1-tm.TASCA/tm[baseline])).median()),
            wins=int((delta < -1e-12).sum()), ties=int((abs(delta) <= 1e-12).sum()), losses=int((delta > 1e-12).sum()),
            family_count=len(fm), family_difference=(fm.TASCA-fm[baseline]).mean(), family_ci_low=flo, family_ci_high=fhi))
        for excluded in tm.index:
            remain = tm.drop(index=excluded)
            sub = cases[(cases.target != excluded) & (cases.policy == 'TASCA')]
            exclusions.append(dict(excluded_target=excluded, baseline=baseline,
                tasca_mse=remain.TASCA.mean(), baseline_mse=remain[baseline].mean(),
                difference=(remain.TASCA-remain[baseline]).mean(),
                gain_pct=100*(1-remain.TASCA.mean()/remain[baseline].mean()),
                source_admissions=int((sub.selected == C).sum())))
    comparison = pd.DataFrame(comparisons)
    comparison.to_csv(OUT / 'paired_comparisons.csv', index=False)
    pd.DataFrame(exclusions).to_csv(OUT / 'leave_one_target_out.csv', index=False)
    # Pigeonhole-style two-axis reweighting is a sensitivity for the original pair-weighted estimand.
    delta = (pivot.TASCA - pivot[N]).groupby(level=['target', 'source']).mean().reset_index(name='difference')
    targets, sources = sorted(delta.target.unique()), sorted(delta.source.unique())
    ti, si = [targets.index(v) for v in delta.target], [sources.index(v) for v in delta.source]
    rng = np.random.default_rng(20261019)
    tw = rng.multinomial(len(targets), [1/len(targets)]*len(targets), 20000)
    sw = rng.multinomial(len(sources), [1/len(sources)]*len(sources), 20000)
    weights = tw[:, ti] * sw[:, si]
    good = weights.sum(axis=1) > 0
    cross = (weights[good] @ delta.difference.to_numpy()) / weights[good].sum(axis=1)
    nodes = []
    for node in sorted(set(targets) | set(sources)):
        rem = pivot[(pivot.index.get_level_values('target') != node) & (pivot.index.get_level_values('source') != node)]
        nodes.append(dict(excluded_node=node, cases=len(rem), difference=float((rem.TASCA-rem[N]).mean())))
    pd.DataFrame(nodes).to_csv(OUT / 'leave_one_dataset_node_out.csv', index=False)
    diag = pd.DataFrame(diagnostics)
    diag.to_csv(OUT / 'admission_diagnostics.csv', index=False)
    diag[diag.source_admitted].to_csv(OUT / 'all_13_admitted_cases.csv', index=False)
    pd.DataFrame(stability).to_csv(OUT / 'leave_one_calibration_window_out.csv', index=False)
    sen = pd.DataFrame(sensitivities)
    sen.to_csv(OUT / 'calibration_sensitivity_cases.csv', index=False)
    sr = []
    for (setting, value), g in sen.groupby(['setting', 'value']):
        sr.append(dict(setting=setting, value=value, case_mean_mse=g.mse.mean(),
            target_macro_mse=g.groupby('target').mse.mean().mean(), admissions=int((g.selected == C).sum()),
            beneficial_admissions=int(((g.selected == C) & g.useful).sum()),
            missed_useful=int(((g.selected != C) & g.useful).sum())))
    pd.DataFrame(sr).to_csv(OUT / 'calibration_sensitivity_summary.csv', index=False)
    # Known five-collection extension: selector comparison is exploratory, never relabeled fresh.
    iw = pd.read_csv(ROOT.parent / 'independent/results/frozen_tasca_v1/window_metrics.csv')
    ir = []
    for key, g in iw[iw.budget == 24].groupby(['family', 'task', 'replication']):
        cal = g[g['split'] == 'calibration'].pivot(index='window', columns='method', values='mse').sort_index()
        test = g[g['split'] == 'test'].groupby('method').mse.mean()
        ll = {m: cal[m].to_numpy() for m in BASE}
        for policy, selected in policies(ll, int(g.raw_width.iloc[0]), int(g.native_used.iloc[0])).items():
            ir.append(dict(zip(['family', 'task', 'replication'], key), policy=policy, selected=selected, mse=test[selected]))
    independent = pd.DataFrame(ir)
    independent.to_csv(OUT / 'known_extension_selector_cases.csv', index=False)
    independent.groupby(['family', 'policy']).mse.mean().groupby('policy').mean().to_csv(OUT / 'known_extension_selector_macro.csv')
    report = {'status': 'complete', 'case_count': 66, 'target_count': 10,
        'source_admitted': int(diag.source_admitted.sum()),
        'admitted_and_better_than_both': int((diag.source_admitted & diag.source_useful).sum()),
        'admitted_not_better_than_both': int((diag.source_admitted & ~diag.source_useful).sum()),
        'rejected_but_better_than_both': int((~diag.source_admitted & diag.source_useful).sum()),
        'calibration_test_spearman_descriptive': float(diag.calibration_gain_vs_best_non_pct.corr(diag.test_gain_vs_best_non_pct, method='spearman')),
        'leave_one_window_change_rate': float(pd.DataFrame(stability).changed.mean()),
        'pairs_changing_across_placements': int(diag.groupby('pair').selected.nunique().gt(1).sum()),
        'crossed_pair_weighted_ci': np.quantile(cross, [.025, .975]).tolist(),
        'crossed_resampling_retained_draws': int(good.sum()),
        'caution': 'Crossed axes do not eliminate cross-role dataset or pretraining dependence. All old-data selector comparisons are exploratory.',
        'seconds': time.perf_counter()-started}
    save_json(OUT / 'summary.json', report)
    print(json.dumps(report, indent=2))
    print(comparison[['baseline', 'target_difference', 'target_ci_low', 'target_ci_high', 'wins', 'ties', 'losses']].to_string(index=False))


if __name__ == '__main__':
    main()
