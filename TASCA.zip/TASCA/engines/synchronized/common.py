"""Shared frozen selectors and auditable file operations for this revision."""
from pathlib import Path
import hashlib
import json
import os
import numpy as np

ROOT = Path(__file__).resolve().parent
T, N, C = 'target_univariate', 'native_all', 'cross_all'
BASE = (T, N, C)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def atomic(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8', newline='') as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def save_json(path, value):
    atomic(path, json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False))


def score(x, penalty=.25):
    x = np.asarray(x, dtype=float)
    mean = float(x.mean())
    return mean + penalty * float(x.std(ddof=1)) if len(x) > 1 and mean > 1e-12 else mean


def choose(losses, width, penalty=.25, margin=.05, threshold=32, source=True):
    if width >= threshold:
        return T
    s = {m: score(losses[m], penalty) for m in BASE}
    non = min((T, N), key=lambda m: (s[m], m))
    best = min(BASE, key=lambda m: (s[m], m)) if source else non
    return non if best == C and (s[non] - s[C]) / max(s[non], 1e-12) < margin else best


def paired_pass(losses, candidate, reference, margin):
    difference = np.asarray(losses[candidate]) - np.asarray(losses[reference])
    return score(difference + 0., 0) + .25 * (difference.std(ddof=1) if len(difference) > 1 else 0) < -margin * max(np.mean(losses[reference]), 1e-12)


def pairwise(losses, width, guard=True):
    if guard and width >= 32:
        return T
    non = N if paired_pass(losses, N, T, 0.) else T
    return C if paired_pass(losses, C, non, .05) else non


def policies(losses, width, retained=None):
    unguarded = choose(losses, width, threshold=float('inf'))
    soft = unguarded
    if width >= 32 and score(losses[unguarded]) > .95 * score(losses[T]):
        soft = T
    out = {m: m for m in BASE}
    out.update(TASCA=choose(losses, width), width_only=T if width >= 32 else N,
               no_width_guard=unguarded, no_dispersion=choose(losses, width, penalty=0),
               no_source_margin=choose(losses, width, margin=0),
               non_source_only=choose(losses, width, source=False),
               calibration_argmin=min(BASE, key=lambda m: (np.mean(losses[m]), m)),
               pairwise_guarded=pairwise(losses, width), pairwise_no_guard=pairwise(losses, width, False),
               conservative_non_source=N if paired_pass(losses, N, T, .05) else T,
               soft_guard=soft,
               retained_width_guard=choose(losses, min(width, 24) if retained is None else retained))
    return out


def bootstrap_means(values, seed=20261019, draws=20000):
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    means = values[rng.integers(0, len(values), (draws, len(values)))].mean(axis=1)
    return np.quantile(means, [.025, .975]).tolist()
