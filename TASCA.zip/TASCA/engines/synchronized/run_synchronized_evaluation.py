"""PyCharm/freqrank_clean: direct Run. Fully offline inference, durable resume."""
import os
os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform
import sqlite3
import time
import numpy as np
import pandas as pd
from common import ROOT, T, N, C, BASE, policies, score, digest, save_json, atomic, bootstrap_means
from synchronized_protocol import read_tasks, prepare, select_windows, L, H, CONDITIONS

OUT = ROOT / 'results/synchronized_v1'
from settings import model_path
MODEL = model_path("chronos-2")


def event(message, **values):
    OUT.mkdir(parents=True, exist_ok=True)
    print(message, flush=True)
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(dict(message=message, time=time.time(), **values), ensure_ascii=False) + '\n')


def payload_array(array):
    return [float(v) if np.isfinite(v) else None for v in array]


def build_protocol():
    tasks = read_tasks()
    plans, exclusions, manifest = [], [], []
    for task in tasks:
        pp = {condition: prepare(task, condition) for condition in CONDITIONS}
        try:
            windows, unavailable = select_windows(task, pp)
        except ValueError as error:
            exclusions.append(dict(collection=task.collection, target=task.target, reason=str(error)))
            continue
        plans.append((task, pp, windows))
        manifest.append(dict(collection=task.collection, target=task.target, **task.metadata, unavailable_windows=unavailable,
            conditions={c: {k: v for k, v in p.items() if k not in ('values', 'observed')}
                        | {'input_sha256': hashlib.sha256(np.nan_to_num(p['values'], nan=123456).tobytes()).hexdigest()}
                        for c, p in pp.items()}, windows=windows))
    model_hash = digest(MODEL / 'model.safetensors')
    frozen = dict(version='synchronous_frozen_v1', context=L, horizon=H, median=.5, dtype='float32',
        batch_size=1, cross_learning=True, seed=42, model_sha256=model_hash,
        chronos_version=importlib.metadata.version('chronos-forecasting'),
        defaults={'lambda': .25, 'gamma': .05, 'raw_width': 32}, tasks=manifest, exclusions=exclusions,
        code_sha256={name: digest(ROOT / name) for name in ('common.py', 'synchronized_protocol.py', 'run_synchronized_evaluation.py')},
        written_design_sha256=digest(ROOT / 'protocols/REVISION_PROTOCOL.md'))
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / 'frozen_protocol.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == frozen, 'Frozen protocol changed; do not mix runs'
    else:
        save_json(path, frozen)
    save_json(OUT / 'exclusions.json', exclusions)
    return plans, frozen


def summarize(db):
    records = [json.loads(p) for p, in db.execute('SELECT payload FROM windows ORDER BY key')]
    if not records:
        return
    d = pd.DataFrame(records)
    d.drop(columns=['prediction', 'truth', 'mask']).to_csv(OUT / 'window_metrics.csv', index=False)
    rows, diagnostics = [], []
    for key, g in d.groupby(['collection', 'target', 'condition', 'block']):
        cal = g[g['split'] == 'calibration'].pivot(index='window', columns='method', values='mse').sort_index()
        test_windows = g[g['split'] == 'test']
        if len(cal) != int(g.expected_calibration.iloc[0]) or any(int((test_windows.method == m).sum()) != int(g.expected_test.iloc[0]) for m in BASE):
            continue
        assert cal[list(BASE)].notna().all().all()
        losses = {m: cal[m].to_numpy() for m in BASE}
        test = test_windows.groupby('method')[['mse', 'mae']].mean()
        choices = policies(losses, int(g.raw_width.iloc[0]))
        metadata = dict(zip(['collection', 'target', 'condition', 'block'], key))
        for policy, selected in choices.items():
            rows.append(dict(metadata, policy=policy, selected=selected, mse=test.loc[selected, 'mse'], mae=test.loc[selected, 'mae']))
        best_non = min((T, N), key=lambda m: (test.loc[m, 'mse'], m))
        cal_non = min((T, N), key=lambda m: (score(losses[m]), m))
        delta = test.loc[C, 'mse'] - test.loc[best_non, 'mse']
        diagnostics.append(dict(metadata, selected=choices['TASCA'], admitted=choices['TASCA'] == C,
            source_useful=bool(delta < -1e-12), source_degraded=bool(delta > 1e-12),
            source_mse=test.loc[C, 'mse'], native_mse=test.loc[N, 'mse'], target_mse=test.loc[T, 'mse'],
            non_source_policy_mse=test.loc[choices['non_source_only'], 'mse'],
            source_vs_best_non_gain_pct=100*(1-test.loc[C, 'mse']/max(test.loc[best_non, 'mse'], 1e-12)),
            source_vs_native_gain_pct=100*(1-test.loc[C, 'mse']/max(test.loc[N, 'mse'], 1e-12)),
            calibration_gain_vs_best_non_pct=100*(1-np.mean(losses[C])/max(min(np.mean(losses[T]), np.mean(losses[N])), 1e-12)),
            score_gain_pct=100*(1-score(losses[C])/max(score(losses[cal_non]), 1e-12))))
    if not rows:
        return
    cases = pd.DataFrame(rows)
    cases.to_csv(OUT / 'case_results.csv', index=False)
    diag = pd.DataFrame(diagnostics)
    diag.to_csv(OUT / 'admission_diagnostics.csv', index=False)
    target = cases.groupby(['condition', 'collection', 'target', 'policy'])[['mse', 'mae']].mean().reset_index()
    target.to_csv(OUT / 'target_results.csv', index=False)
    collection = target.groupby(['condition', 'collection', 'policy'])[['mse', 'mae']].mean().reset_index()
    collection.to_csv(OUT / 'collection_results.csv', index=False)
    collection.groupby(['condition', 'policy'])[['mse', 'mae']].mean().to_csv(OUT / 'macro_results.csv')
    comparisons, admission_summary, loto = [], [], []
    for condition, g in collection.groupby('condition'):
        pivot = g.pivot(index='collection', columns='policy', values='mse')
        for baseline in (N, T, 'non_source_only', 'pairwise_guarded', 'conservative_non_source', 'calibration_argmin'):
            delta = pivot.TASCA-pivot[baseline]
            lo, hi = bootstrap_means(delta)
            comparisons.append(dict(condition=condition, baseline=baseline, collections=len(pivot),
                tasca_mse=pivot.TASCA.mean(), baseline_mse=pivot[baseline].mean(), difference=delta.mean(),
                gain_pct=100*(1-pivot.TASCA.mean()/pivot[baseline].mean()), ci_low=lo, ci_high=hi))
        for omitted in pivot.index:
            r = pivot.drop(index=omitted)
            loto.append(dict(condition=condition, excluded=omitted, difference_vs_native=float((r.TASCA-r[N]).mean())))
        dd = diag[diag.condition == condition]
        admission_summary.append(dict(condition=condition, cases=len(dd), admitted=int(dd.admitted.sum()),
            admitted_improved=int((dd.admitted & dd.source_useful).sum()),
            admitted_degraded=int((dd.admitted & dd.source_degraded).sum()),
            rejected_useful=int((~dd.admitted & dd.source_useful).sum())))
    pd.DataFrame(comparisons).to_csv(OUT / 'comparisons.csv', index=False)
    pd.DataFrame(admission_summary).to_csv(OUT / 'admission_summary.csv', index=False)
    pd.DataFrame(loto).to_csv(OUT / 'leave_one_collection_out.csv', index=False)
    actual = d[~d.cached_prediction & ~d.first_physical_call]
    actual.groupby(['method', 'input_channels']).agg(calls=('inference_seconds','count'),
        median_seconds=('inference_seconds','median'), total_seconds=('inference_seconds','sum'),
        max_gpu_gb=('peak_allocated_gb','max')).reset_index().to_csv(OUT / 'inference_cost.csv', index=False)
    cost = d.groupby(['collection', 'target', 'condition', 'block', 'split']).agg(
        logical_calls=('key','count'), physical_calls=('cached_prediction', lambda x:int((~x).sum())),
        actual_gpu_seconds=('inference_seconds','sum')).reset_index()
    cost.to_csv(OUT / 'stage_cost.csv', index=False)


def main():
    plans, frozen = build_protocol()
    event('Protocol frozen before model loading', tasks=len(plans), exclusions=len(frozen['exclusions']))
    import torch
    from chronos import Chronos2Pipeline
    torch.set_num_threads(4)
    torch.manual_seed(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    assert torch.cuda.is_available(), 'Expected the local CUDA research environment'
    pipeline = Chronos2Pipeline.from_pretrained(str(MODEL), device_map='cuda', torch_dtype=torch.float32, local_files_only=True)
    pipeline.model.eval()
    assert next(pipeline.model.parameters()).dtype == torch.float32
    median = list(pipeline.quantiles).index(.5)
    save_json(OUT / 'environment.json', dict(python=platform.python_version(), torch=torch.__version__,
        gpu=torch.cuda.get_device_name(0), chronos=frozen['chronos_version'], model_sha256=frozen['model_sha256']))
    db = sqlite3.connect(OUT / 'predictions.sqlite')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    db.execute('CREATE TABLE IF NOT EXISTS predictions(key TEXT PRIMARY KEY,payload TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS windows(key TEXT PRIMARY KEY,payload TEXT)')
    db.commit()
    started, calls = time.perf_counter(), 0
    for task, pp, windows in plans:
        for condition, prepared in pp.items():
            values, obs, native = prepared['values'], prepared['observed'], prepared['native']
            channel_map = {T: [0], N: list(range(native)), C: list(range(values.shape[1]))}
            for w in windows:
                origin = w['origin']
                assert task.frame.index[origin-1-prepared['source_lag']] < task.frame.index[origin]
                for method, indices in channel_map.items():
                    key = json.dumps([task.collection, task.target, condition, w['block'], w['split'], w['window'], method])
                    if db.execute('SELECT 1 FROM windows WHERE key=?', (key,)).fetchone():
                        continue
                    x = np.ascontiguousarray(values[origin-L:origin, indices].T, dtype=np.float32)
                    pk = hashlib.sha256(json.dumps([frozen['model_sha256'], x.shape, H, L, frozen['chronos_version']]).encode() + x.tobytes()).hexdigest()
                    found = db.execute('SELECT payload FROM predictions WHERE key=?', (pk,)).fetchone()
                    latency, peak, first = 0., 0., False
                    if found:
                        pred = np.asarray(json.loads(found[0])['prediction'])
                    else:
                        first = calls == 0
                        torch.cuda.synchronize()
                        torch.cuda.reset_peak_memory_stats()
                        before = time.perf_counter()
                        with torch.inference_mode():
                            output = pipeline.predict([x], prediction_length=H, context_length=L, batch_size=1, cross_learning=True)[0]
                            pred = output[0, median].cpu().numpy().astype(float)
                        torch.cuda.synchronize()
                        latency = time.perf_counter()-before
                        peak = torch.cuda.max_memory_allocated()/1e9
                        assert pred.shape == (H,) and np.isfinite(pred).all()
                        db.execute('INSERT INTO predictions VALUES (?,?)', (pk, json.dumps({'prediction': pred.tolist()})))
                        db.commit()
                        calls += 1
                    truth, mask = values[origin:origin+H, 0].astype(float), obs[origin:origin+H]
                    error = pred[mask]-truth[mask]
                    row = dict(key=key, collection=task.collection, target=task.target, condition=condition,
                        **w, method=method, raw_width=len(task.native), input_channels=len(indices),
                        source_columns=prepared['columns'][native:], source_lag=prepared['source_lag'],
                        native_columns=prepared['columns'][:native], forecast_timestamp=str(task.frame.index[origin]),
                        last_source_timestamp=str(task.frame.index[origin-1-prepared['source_lag']]),
                        mse=float(np.mean(error**2)), mae=float(np.mean(abs(error))), observed=int(mask.sum()),
                        truth=payload_array(truth), prediction=pred.tolist(), mask=mask.tolist(),
                        cache_key=pk, cached_prediction=bool(found), inference_seconds=latency,
                        peak_allocated_gb=peak, first_physical_call=first)
                    db.execute('INSERT INTO windows VALUES (?,?)', (key, json.dumps(row, allow_nan=False)))
                    db.commit()
                save_json(OUT / 'status.json', dict(complete=False, collection=task.collection,
                    target=task.target, condition=condition, window=w, new_calls=calls))
            summarize(db)
            event('Completed target/source condition', collection=task.collection, target=task.target, condition=condition, new_calls=calls)
    summarize(db)
    maximum, records = 0., []
    for p, in db.execute('SELECT payload FROM windows ORDER BY key'):
        r = json.loads(p)
        y, pred, mask = np.asarray(r['truth'], float), np.asarray(r['prediction']), np.asarray(r['mask'], bool)
        for name, value in [('mse', np.mean((pred[mask]-y[mask])**2)), ('mae', np.mean(abs(pred[mask]-y[mask])))]:
            maximum = max(maximum, abs(value-r[name]))
        records.append(p)
    assert maximum < 1e-12 and len(records) == sum(len(windows) for _, _, windows in plans)*len(CONDITIONS)*3
    atomic(OUT / 'predictions.jsonl', '\n'.join(records)+'\n')
    assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
    db.close()
    save_json(OUT / 'completion.json', dict(complete=True, logical_windows=len(records),
        actual_new_calls=calls, maximum_metric_difference=maximum, seconds=time.perf_counter()-started,
        source_code_sha256=frozen['code_sha256'], protocol_sha256=digest(OUT/'frozen_protocol.json')))
    save_json(OUT / 'status.json', dict(complete=True, logical_windows=len(records)))
    event('All synchronized experiments complete', logical_windows=len(records), new_calls=calls)
    print(pd.read_csv(OUT / 'comparisons.csv').to_string(index=False))
    print(pd.read_csv(OUT / 'admission_summary.csv').to_string(index=False))


if __name__ == '__main__':
    main()
