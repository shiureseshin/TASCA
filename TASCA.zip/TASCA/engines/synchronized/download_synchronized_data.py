"""PyCharm Run: obtain three original UCI archives once, then operate offline."""
from pathlib import Path
import io
import zipfile
import requests
from common import ROOT, digest, save_json

from settings import data_path
DATA = data_path("synchronized")
SOURCES = {
    'air_quality': 'https://archive.ics.uci.edu/static/public/360/air+quality.zip',
    'capital_bike': 'https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip',
    'seoul_bike': 'https://archive.ics.uci.edu/static/public/560/seoul+bike+sharing+demand.zip',
}


def main():
    manifest = []
    for name, url in SOURCES.items():
        folder = DATA / name
        folder.mkdir(parents=True, exist_ok=True)
        archive = folder / 'original.zip'
        if not archive.exists():
            session = requests.Session()
            session.trust_env = False
            response = session.get(url, timeout=(20, 90))
            response.raise_for_status()
            with zipfile.ZipFile(io.BytesIO(response.content)) as zipped:
                assert zipped.testzip() is None
            temporary = archive.with_suffix('.tmp')
            temporary.write_bytes(response.content)
            temporary.replace(archive)
        with zipfile.ZipFile(archive) as zipped:
            for entry in zipped.infolist():
                if entry.is_dir() or Path(entry.filename).suffix.lower() not in ('.csv', '.txt'):
                    continue
                destination = folder / Path(entry.filename).name
                content = zipped.read(entry)
                if destination.exists():
                    assert destination.read_bytes() == content
                else:
                    destination.write_bytes(content)
        manifest.append({'dataset': name, 'url': url, 'archive': str(archive),
                         'sha256': digest(archive), 'files': [str(p) for p in folder.glob('*.csv')]})
        print(name + ' downloaded and verified', flush=True)
    save_json(ROOT / 'audit/download_manifest.json', manifest)


if __name__ == '__main__':
    main()
