"""Causal, timestamp-preserving preparation; no model access in this module."""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT, digest
from download_synchronized_data import DATA

L, H = 96, 24
CONDITIONS = ('full_weather', 'correlation_top2', 'stale_week')


@dataclass
class Task:
    collection: str
    target: str
    frame: pd.DataFrame
    native: list
    source: list
    file: Path
    metadata: dict


def read_tasks():
    tasks = []
    for family in ('air_quality', 'capital_bike', 'seoul_bike'):
        if family == 'air_quality':
            file = DATA / family / 'AirQualityUCI.csv'
            raw = pd.read_csv(file, sep=';', decimal=',').dropna(subset=['Date', 'Time'])
            dates = pd.to_datetime(raw.Date + ' ' + raw.Time, format='%d/%m/%Y %H.%M.%S')
            native = ['CO(GT)', 'C6H6(GT)', 'NOx(GT)', 'NO2(GT)']
            source = ['T', 'RH', 'AH']
            raw = raw[native + source].replace(-200., np.nan)
        elif family == 'capital_bike':
            file = DATA / family / 'hour.csv'
            raw = pd.read_csv(file)
            dates = pd.to_datetime(raw.dteday) + pd.to_timedelta(raw.hr, unit='h')
            native, source = ['cnt', 'casual', 'registered'], ['temp', 'atemp', 'hum', 'windspeed']
            assert (raw.cnt == raw.casual + raw.registered).all()
            raw = raw[native + source]
        else:
            file = DATA / family / 'SeoulBikeData.csv'
            raw = pd.read_csv(file, encoding='latin1')
            dates = pd.to_datetime(raw.Date, format='%d/%m/%Y') + pd.to_timedelta(raw.Hour, unit='h')
            native = ['Rented Bike Count']
            source = list(raw.columns[3:11])
            assert len(source) == 8
            raw = raw[native + source]
        raw = raw.astype(float)
        raw.index = pd.DatetimeIndex(dates)
        duplicates = int(raw.index.duplicated().sum())
        grouped = raw.groupby(level=0).mean().sort_index()
        grid = pd.date_range(grouped.index.min(), grouped.index.max(), freq='h')
        frame = grouped.reindex(grid).iloc[:7000]
        assert frame.index.is_monotonic_increasing and frame.index.is_unique
        assert (frame.index.to_series().diff().dropna() == pd.Timedelta(hours=1)).all()
        meta = dict(raw_rows=len(raw), grid_rows=len(frame), duplicate_rows=duplicates,
                    missing_grid_hours=int((~frame.index.isin(grouped.index)).sum()),
                    first_timestamp=str(frame.index[0]), last_timestamp=str(frame.index[-1]),
                    source_file_sha256=digest(file), raw_width=len(native), source_width=len(source),
                    native_columns=native, source_columns=source)
        for target in native:
            tasks.append(Task(family, target, frame, [target] + [n for n in native if n != target], source, file, meta))
    return tasks


def standardize(raw, split):
    filled = raw.ffill()
    train = filled.iloc[:split]
    mean, scale = train.mean(), train.std(ddof=0)
    assert mean.notna().all()
    scale = scale.mask(scale < 1e-6, 1.)
    values = ((filled - mean) / scale).to_numpy(dtype=np.float32)
    return values, {'mean': mean.to_dict(), 'scale': scale.to_dict()}


def prepare(task, condition):
    split = int(len(task.frame) * .7)
    native = task.frame[task.native]
    lag = 169 if condition == 'stale_week' else 1
    source = task.frame[task.source].shift(lag)
    if condition == 'correlation_top2':
        # Pairwise-complete TRAINING observations only, with the same source latency.
        correlations = source.iloc[:split].corrwith(native[task.target].iloc[:split]).abs().fillna(0.)
        columns = sorted(task.source, key=lambda s: (-correlations[s], s))[:2]
        source = source[columns]
    raw = pd.concat([native, source], axis=1)
    values, scalers = standardize(raw, split)
    observation = task.frame[task.target].notna().to_numpy()
    return dict(values=values, observed=observation, split=split, native=len(native.columns),
                raw_width=len(task.native), columns=list(raw.columns), source_lag=lag, scalers=scalers)


def select_windows(task, prepared):
    n, split = len(task.frame), prepared['full_weather']['split']
    bounds = np.linspace(split, n, 3).astype(int)
    out, exclusions = [], []
    for block in range(2):
        edges = np.linspace(bounds[block], bounds[block+1], 17).astype(int)
        for i, (left, right) in enumerate(zip(edges[:-1], edges[1:])):
            candidates = []
            for origin in range(max(left, L), right - H + 1):
                observed = int(prepared['full_weather']['observed'][origin:origin+H].sum())
                finite = all(np.isfinite(p['values'][origin-L:origin]).all() for p in prepared.values())
                if observed >= 18 and finite:
                    candidates.append((-observed, abs(origin - (left+right-H)/2), origin))
            if not candidates:
                exclusions.append(dict(block=block, bin=i, reason='No finite history with at least18 observed future labels in fixed bin'))
                continue
            origin = min(candidates)[2]
            out.append(dict(block=block, split='calibration' if i < 6 else 'test', window=i if i < 6 else i-6,
                            origin=origin, end=origin+H, timestamp=str(task.frame.index[origin]), bin_left=int(left), bin_right=int(right)))
    for block in range(2):
        ww = [w for w in out if w['block'] == block]
        nc = sum(w['split'] == 'calibration' for w in ww)
        nt = sum(w['split'] == 'test' for w in ww)
        if nc < 3 or nt < 6:
            exclusions.append(dict(block=block, reason='Fewer than3 calibration or6 test windows', calibration=nc, test=nt))
            out = [w for w in out if w['block'] != block]
            continue
        for w in ww:
            w['expected_calibration'] = nc
            w['expected_test'] = nt
        assert all(a['end'] <= b['origin'] for a, b in zip(ww[:-1], ww[1:]))
        assert max(w['end'] for w in ww if w['split'] == 'calibration') <= min(w['origin'] for w in ww if w['split'] == 'test')
    if not out:
        raise ValueError(f'No eligible block for {task.collection}/{task.target}: {exclusions}')
    return out, exclusions
