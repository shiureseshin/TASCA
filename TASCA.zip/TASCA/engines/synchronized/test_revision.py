"""Direct PyCharm Run: selector, leakage, window, and real-data protocol tests."""
import unittest
import numpy as np
import pandas as pd
from common import T, N, C, choose, policies, pairwise, ROOT, save_json
from synchronized_protocol import standardize, read_tasks, prepare, select_windows, CONDITIONS, H, L


class RevisionTests(unittest.TestCase):
    def test_guard_and_margin(self):
        losses = {T: [1., 1., 1.], N: [.8, .8, .8], C: [.7, .7, .7]}
        self.assertEqual(choose(losses, 32), T)
        self.assertEqual(choose(losses, 4), C)
        losses[C] = [.79, .79, .79]
        self.assertEqual(choose(losses, 4), N)

    def test_pairwise_uses_paired_variability(self):
        losses = {T: [1., 2., 3.], N: [.9, 1.9, 2.9], C: [.5, 1.5, 2.5]}
        self.assertEqual(pairwise(losses, 4), C)
        self.assertEqual(pairwise(losses, 40), T)

    def test_frozen_scaling_and_history(self):
        x = pd.DataFrame({'x': [np.nan, 1., 2., np.nan, 4., 5., 6., 7.]})
        z, s = standardize(x, 4)
        y = x.copy()
        y.iloc[6:] = 1e9
        zz, ss = standardize(y, 4)
        self.assertEqual(s, ss)
        np.testing.assert_allclose(z[:6], zz[:6], equal_nan=True)
        self.assertTrue(np.isnan(z[0, 0]))
        self.assertEqual(z[2, 0], z[3, 0])

    def test_masked_loss(self):
        y, pred = np.array([1., np.nan, 3.]), np.array([2., 999., 4.])
        mask = np.isfinite(y)
        self.assertEqual(float(np.mean((y[mask]-pred[mask])**2)), 1.)

    def test_retained_guard_degeneracy(self):
        ll = {T: [2., 2.], N: [1., 1.], C: [.8, .8]}
        for width in (7, 21, 59, 321):
            p = policies(ll, width)
            self.assertEqual(p['retained_width_guard'], p['no_width_guard'])

    def test_real_data_windows_and_future_perturbation(self):
        tasks = read_tasks()
        self.assertEqual(len(tasks), 8)
        for task in tasks:
            pp = {condition: prepare(task, condition) for condition in CONDITIONS}
            ww, excluded = select_windows(task, pp)
            self.assertLessEqual(len(ww), 32)
            self.assertGreater(len(ww), 0)
            for w in ww:
                self.assertGreaterEqual(w['expected_calibration'], 3)
                self.assertGreaterEqual(w['expected_test'], 6)
            origin = ww[0]['origin']
            before = prepare(task, 'full_weather')
            old = task.frame.copy()
            task.frame.iloc[origin:] = task.frame.iloc[origin:] + 1e6
            after = prepare(task, 'full_weather')
            self.assertEqual(before['scalers'], after['scalers'])
            np.testing.assert_array_equal(before['values'][origin-L:origin], after['values'][origin-L:origin])
            task.frame = old
            for w in ww:
                self.assertGreaterEqual(int(before['observed'][w['origin']:w['end']].sum()), 18)
                self.assertEqual(w['end']-w['origin'], H)
                self.assertLess(task.frame.index[w['origin']-2], task.frame.index[w['origin']])


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RevisionTests))
    save_json(ROOT / 'audit/unit_tests.json', {'tests': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'successful': result.wasSuccessful()})
    raise SystemExit(0 if result.wasSuccessful() else 1)
