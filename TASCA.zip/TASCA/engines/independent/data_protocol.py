"""Outcome-blind data preparation and fixed evaluation windows."""
from dataclasses import dataclass
from pathlib import Path
import hashlib
import io
import json
import re
import zipfile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
from settings import data_path, independent_manifest
DATA = data_path("independent")
MAX_ROWS = 7000
CONTEXT = 96
HORIZON = 24
BUDGETS = (8, 16, 24, 48)
SOURCE_BUDGET = 24
CALIBRATION_WINDOWS = 6
TEST_WINDOWS = 10
METHODS = ("target_univariate", "native_all", "cross_all")


@dataclass
class Dataset:
    name: str
    family: str
    frame: pd.DataFrame
    targets: tuple
    frequency: str
    description: str


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_zip_csv(name, suffix, **kwargs):
    with zipfile.ZipFile(DATA / name) as archive:
        member = next(n for n in archive.namelist() if n.lower().endswith(suffix.lower()))
        return pd.read_csv(io.BytesIO(archive.read(member)), **kwargs)


def regular_frame(frame, dates, frequency):
    frame = frame.copy()
    frame.index = pd.DatetimeIndex(dates)
    frame = frame.loc[~frame.index.duplicated(keep="first")].sort_index()
    return frame.apply(pd.to_numeric, errors="coerce").asfreq(frequency)


def load_datasets():
    datasets = {}
    if (DATA / "appliances_author.csv").exists():
        raw = pd.read_csv(DATA / "appliances_author.csv")
    else:
        raw = read_zip_csv("appliances.zip", "energydata_complete.csv")
    frame = regular_frame(raw.drop(columns=["date", "rv1", "rv2"]), pd.to_datetime(raw.date), "10min")
    datasets["appliances"] = Dataset("appliances", "appliances", frame,
                                     ("Appliances", "T1"), "10min", "Observed sensors; exclude the two artificial random variables.")

    sml_names = ["date", "time", "dining_temperature", "room_temperature", "forecast_temperature",
                 "dining_co2", "room_co2", "dining_humidity", "room_humidity", "dining_light",
                 "room_light", "rain", "dusk", "wind", "west_light", "east_light", "south_light",
                 "irradiance", "motor1", "motor2", "motor_turbo", "outdoor_temperature",
                 "outdoor_humidity", "weekday"]
    frames = []
    with zipfile.ZipFile(DATA / "sml2010.zip") as archive:
        for member in sorted(n for n in archive.namelist() if n.endswith(".T15.txt")):
            raw = pd.read_csv(io.BytesIO(archive.read(member)), sep=r"\s+", comment="#", header=None)
            if raw.shape[1] != len(sml_names):
                raise ValueError("Unexpected SML schema: " + str(raw.shape))
            raw.columns = sml_names
            dates = pd.to_datetime(raw.date + " " + raw.time, dayfirst=True)
            frames.append(regular_frame(raw.drop(columns=["date", "time", "weekday"]), dates, "15min"))
    frame = pd.concat(frames).sort_index()
    frame = frame.loc[~frame.index.duplicated(keep="first")]
    # File boundaries can contain long gaps. Keep the longest observed regular run.
    groups = frame.index.to_series().diff().ne(pd.Timedelta("15min")).cumsum().to_numpy()
    lengths = pd.Series(groups).value_counts()
    frame = frame.loc[groups == lengths.index[0]]
    datasets["sml2010"] = Dataset("sml2010", "sml2010", frame,
                                 ("dining_temperature", "room_temperature"), "15min",
                                 "Longest contiguous run across official files; omit calendar weekday.")

    raw = read_zip_csv("tetouan.zip", ".csv")
    raw.columns = [c.strip() for c in raw.columns]
    date_col = next(c for c in raw.columns if c.lower() == "datetime")
    frame = regular_frame(raw.drop(columns=[date_col]), pd.to_datetime(raw[date_col]), "10min")
    targets = tuple(c for c in frame if "consumption" in c.lower())
    assert len(targets) == 3
    datasets["tetouan"] = Dataset("tetouan", "tetouan", frame, targets, "10min", "Three measured distribution-zone loads.")

    manifests = independent_manifest()
    hai_path = next(Path(x["file"]) for x in manifests if "hai20" in Path(x["file"]).name)
    raw = pd.read_csv(hai_path, sep=";")
    labels = [c for c in raw if "attack" in c.lower()]
    if labels and raw[labels].fillna(0).to_numpy().max() != 0:
        raise ValueError("Selected HAI training file contains attack labels")
    time_col = next(c for c in raw if c.lower() in {"time", "timestamp", "datetime"})
    frame = raw.drop(columns=[time_col] + labels).apply(pd.to_numeric, errors="raise")
    frame.index = pd.to_datetime(raw[time_col])
    if frame.index.duplicated().any() or not frame.index.is_monotonic_increasing:
        raise ValueError("HAI timestamps must be unique and chronological")
    # Each timestamp denotes a completed minute; future samples never enter it.
    resampler = frame.resample("1min", closed="right", label="right")
    counts = resampler.size()
    frame = resampler.mean().where(counts.eq(60), axis=0)
    complete_minutes = counts[counts.eq(60)].index
    frame = frame.loc[complete_minutes[0]:complete_minutes[-1]]
    candidates = [c for c in frame if re.search(r"P1[_.](FT01|LIT01|PIT01)$", c)]
    if len(candidates) != 3:
        raise ValueError("Audit HAI target names before freezing: " + str(list(frame.columns)))
    datasets["hai20"] = Dataset("hai20", "hai20", frame, tuple(sorted(candidates)), "min",
                               "Normal train1 only; completed-minute averages; HIL-augmented physical testbed.")

    with zipfile.ZipFile(DATA / "beijing_multisite.zip") as archive:
        inner = next(n for n in archive.namelist() if n.endswith(".zip"))
        with zipfile.ZipFile(io.BytesIO(archive.read(inner))) as stations:
            files = sorted(n for n in stations.namelist() if n.endswith(".csv") and "/._" not in n)
            station_frames = []
            names = []
            columns = ["PM2.5", "PM10", "SO2", "NO2", "CO", "O3", "TEMP", "PRES", "DEWP", "RAIN", "WSPM"]
            for member in files:
                raw = pd.read_csv(io.BytesIO(stations.read(member)))
                station = str(raw.station.iloc[0])
                dates = pd.to_datetime(raw[["year", "month", "day", "hour"]])
                frame = regular_frame(raw[columns], dates, "h").add_prefix(station + "__")
                names.append(station)
                station_frames.append(frame)
    order = np.argsort(names)
    names = [names[i] for i in order]
    station_frames = [station_frames[i] for i in order]
    if len(names) != 12:
        raise ValueError("Expected 12 Beijing stations")
    for label, sl in [("A", slice(0, 6)), ("B", slice(6, 12))]:
        frame = pd.concat(station_frames[sl], axis=1, join="inner")
        chosen = names[sl][:2]
        name = "beijing_" + label
        datasets[name] = Dataset(name, "beijing_multisite", frame,
                                tuple(s + "__PM2.5" for s in chosen), "h",
                                "Six alphabetically assigned stations, 11 measured numeric variables each; new collection in a previously studied application domain.")
    return datasets


SOURCES = {"appliances": "tetouan", "sml2010": "appliances", "tetouan": "sml2010",
           "hai20": "tetouan", "beijing_A": "beijing_B", "beijing_B": "beijing_A"}


def causal_prepare(raw):
    raw = raw.replace([np.inf, -np.inf], np.nan)
    observed = raw.notna()
    filled = raw.ffill()
    complete = filled.notna().all(axis=1).to_numpy()
    if not complete.any():
        raise ValueError("No point with historical observations for every channel")
    first = int(np.flatnonzero(complete)[0])
    # Only a leading prefix is removed; gaps are never joined by dropping rows.
    return filled.iloc[first:], observed.iloc[first:]


def pair_frames(target, source):
    t, tm = causal_prepare(target.frame)
    s, _ = causal_prepare(source.frame)
    alignment = "timestamp" if target.name.startswith("beijing") else "row_index_pattern_transfer"
    if alignment == "timestamp":
        common = t.index.intersection(s.index).sort_values()[-MAX_ROWS:]
        t, tm, s = t.loc[common], tm.loc[common], s.loc[common]
    else:
        n = min(len(t), len(s), MAX_ROWS)
        t, tm, s = t.iloc[-n:], tm.iloc[-n:], s.iloc[-n:]
    assert len(t) == len(s)
    return t, tm, s, alignment


def fixed_windows(observed, n):
    train_end = int(n * 0.70)
    boundaries = [train_end, int(n * 0.85), n]
    out = []
    for rep, (a, b) in enumerate(zip(boundaries[:-1], boundaries[1:])):
        middle = a + (b - a) * CALIBRATION_WINDOWS // (CALIBRATION_WINDOWS + TEST_WINDOWS)
        for split, start, end, count in [("calibration", a, middle, CALIBRATION_WINDOWS),
                                         ("test", middle, b, TEST_WINDOWS)]:
            edges = np.linspace(start, end, count + 1).astype(int)
            for window, (left, right) in enumerate(zip(edges[:-1], edges[1:])):
                if right - left < HORIZON or left < CONTEXT:
                    raise ValueError("Too few contiguous observations for nonoverlapping protocol")
                starts = range(left, right - HORIZON + 1)
                # Availability-only rule, fixed before any predictions: maximum observed labels,
                # then closest to the bin midpoint, then earliest origin.
                center = (left + right - HORIZON) / 2
                origin = min(starts, key=lambda p: (-int(observed[p:p + HORIZON].sum()), abs(p - center), p))
                valid = int(observed[origin:origin + HORIZON].sum())
                if valid < 18:
                    raise ValueError("Insufficient observed target labels in a prespecified bin")
                out.append({"replication": rep, "split": split, "window": window,
                            "origin": origin, "observed_labels": valid, "bin_left": int(left), "bin_right": int(right)})
    intervals = sorted((w["origin"], w["origin"] + HORIZON) for w in out)
    assert all(x[1] <= y[0] for x, y in zip(intervals[:-1], intervals[1:]))
    return out


def rank_columns(frame, train_end, target=None):
    var = frame.iloc[:train_end].var(ddof=1)
    others = sorted((c for c in frame if c != target), key=lambda c: (-float(var[c]), c))
    return ([target] if target is not None else []) + others


def build_tasks(datasets):
    tasks, audit = [], []
    for name, data in datasets.items():
        source = datasets[SOURCES[name]]
        frame, observed, source_frame, alignment = pair_frames(data, source)
        n = len(frame)
        train_end = int(n * 0.70)
        tmean, tstd = frame.iloc[:train_end].mean(), frame.iloc[:train_end].std(ddof=0)
        smean, sstd = source_frame.iloc[:train_end].mean(), source_frame.iloc[:train_end].std(ddof=0)
        tstd = tstd.mask(tstd < 1e-6, 1.0)
        sstd = sstd.mask(sstd < 1e-6, 1.0)
        st = ((frame - tmean) / tstd).astype(np.float32)
        ss = ((source_frame - smean) / sstd).astype(np.float32)
        audit.append({"dataset": name, "family": data.family, "rows_after_adapter": len(data.frame), "rows_used": n,
                      "raw_width": frame.shape[1], "source": source.name, "source_width": source_frame.shape[1],
                      "train_end": train_end, "frequency": data.frequency, "alignment": alignment,
                      "start": str(frame.index[0]), "end": str(frame.index[-1]),
                      "missing_fraction": float(1 - observed.to_numpy().mean()),
                      "constant_train_channels": int((frame.iloc[:train_end].var() < 1e-12).sum()),
                      "description": data.description})
        for column in data.targets:
            if frame[column].iloc[:train_end].var() < 1e-12:
                raise ValueError("Prespecified target constant in training: " + name + ":" + column)
            windows = fixed_windows(observed[column].to_numpy(), n)
            tasks.append({"task": name + "__" + column, "dataset": name, "family": data.family,
                          "target": column, "source": source.name, "raw_width": frame.shape[1],
                          "target_frame": st, "source_frame": ss,
                          "native_rank": rank_columns(frame, train_end, column),
                          "source_rank": rank_columns(source_frame, train_end)[:SOURCE_BUDGET],
                          "observed": observed[column].to_numpy(), "windows": windows,
                          "target_scale_mean": float(tmean[column]), "target_scale_std": float(tstd[column]),
                          "frequency": data.frequency, "alignment": alignment})
    return tasks, pd.DataFrame(audit)


if __name__ == "__main__":
    datasets = load_datasets()
    for name, data in datasets.items():
        print(name, data.frame.shape, data.targets, data.frame.index.min(), data.frame.index.max())
    tasks, audit = build_tasks(datasets)
    audit.to_csv(ROOT / "data_audit.csv", index=False)
    print(audit.to_string(index=False))
    print("Forecast tasks:", len(tasks), "cases at each budget:", len(tasks) * 2)
