"""Unit tests that do not load model weights or access the network."""
import tempfile
from pathlib import Path
import unittest
import importlib.util
import sys
import numpy as np
import pandas as pd
import data_protocol as data
import independent_validation as run


class RulesTest(unittest.TestCase):
    def test_matches_original_tasca_implementation(self):
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "core"))
        from corrected_benchmark import choose
        rng = np.random.default_rng(47)
        for width in [8,21,26,31,32,59,66]:
            for _ in range(16):
                losses = {m:rng.uniform(0,2,6).tolist() for m in run.METHODS}
                self.assertEqual(run.choose_tasca(losses,width), choose(losses,width))

    def test_width_guard_overrides_source_gain(self):
        loss = {run.T: [2, 2], run.N: [1, 1], run.C: [0.1, 0.1]}
        self.assertEqual(run.choose_tasca(loss, 31), run.C)
        self.assertEqual(run.choose_tasca(loss, 32), run.T)

    def test_source_margin(self):
        loss = {run.T: [2, 2], run.N: [1, 1], run.C: [0.96, 0.96]}
        self.assertEqual(run.choose_tasca(loss, 8), run.N)
        loss[run.C] = [0.94, 0.94]
        self.assertEqual(run.choose_tasca(loss, 8), run.C)

    def test_dispersion_and_one_window(self):
        loss = {run.T: [1, 3], run.N: [2, 2], run.C: [4, 4]}
        score = run.scores_from_calibration(loss)
        self.assertAlmostEqual(score[run.T], 2 + 0.25 * np.sqrt(2))
        self.assertEqual(run.choose_tasca(loss, 8), run.N)
        self.assertEqual(run.scores_from_calibration({m: [0.0] for m in run.METHODS}), {m: 0.0 for m in run.METHODS})

    def test_tie_order(self):
        loss = {m: [1, 1] for m in run.METHODS}
        self.assertEqual(run.choose_tasca(loss, 8, margin=0), run.C)
        self.assertEqual(run.choose_tasca(loss, 8), run.N)

    def test_no_forward_imputation(self):
        raw = pd.DataFrame({"a": [np.nan, 1, np.nan, 9], "b": [2, 2, 3, 4]})
        filled, mask = data.causal_prepare(raw)
        self.assertEqual(filled.a.tolist(), [1, 1, 9])
        self.assertEqual(mask.a.tolist(), [True, False, True])
        changed = raw.copy()
        changed.loc[3, "a"] = 99
        filled2, _ = data.causal_prepare(changed)
        self.assertEqual(filled2.loc[2, "a"], 1)

    def test_windows_disjoint_and_no_test_labels_in_calibration(self):
        windows = data.fixed_windows(np.ones(2764, dtype=bool), 2764)
        self.assertEqual(len(windows), 32)
        previous_end = 0
        for window in sorted(windows, key=lambda x: x["origin"]):
            self.assertGreaterEqual(window["origin"], previous_end)
            previous_end = window["origin"] + data.HORIZON
        for rep in [0, 1]:
            cal = [w for w in windows if w["replication"] == rep and w["split"] == "calibration"]
            test = [w for w in windows if w["replication"] == rep and w["split"] == "test"]
            self.assertEqual(len(cal), 6)
            self.assertEqual(len(test), 10)
            self.assertLessEqual(max(w["origin"] + data.HORIZON for w in cal), min(w["origin"] for w in test))

    def test_training_only_channel_ranking(self):
        frame = pd.DataFrame({"y": [0, 1, 2, 3], "x": [0, 4, 0, 0], "z": [0, 1, 999, 999]})
        self.assertEqual(data.rank_columns(frame, 2, "y"), ["y", "x", "z"])

    def test_transactional_resume(self):
        old = run.RESULTS
        try:
            with tempfile.TemporaryDirectory() as directory:
                run.RESULTS = Path(directory)
                store = run.Store()
                store.put("predictions", "abc", {"prediction": [1, 2]})
                store.close()
                store = run.Store()
                self.assertEqual(store.get("predictions", "abc")["prediction"], [1, 2])
                self.assertEqual(store.db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
                store.close()
        finally:
            run.RESULTS = old


if __name__ == "__main__":
    unittest.main(verbosity=2)
