"""Frozen TASCA validation. Open in PyCharm/freqrank_clean and click Run.

Prediction is fully offline. Completed forecasts are transactionally cached in
SQLite; reopening this file resumes an interrupted run and regenerates reports.
No old experiment or manuscript file is modified.
"""
from __future__ import annotations

import os
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import time
import traceback

import numpy as np
import pandas as pd

from data_protocol import (ROOT, BUDGETS, CONTEXT, HORIZON, SOURCE_BUDGET, METHODS,
                           load_datasets, build_tasks, sha256)

from settings import model_path, independent_manifest
MODEL = model_path("chronos-2")
RESULTS = ROOT / "results" / "frozen_tasca_v1"
SEED = 20260930
T, N, C = METHODS


def now():
    return datetime.now(timezone.utc).isoformat()


def atomic_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="") as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False)


def log(event, **items):
    record = {"utc": now(), "event": event, **items}
    with (RESULTS / "events.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(canonical(record) + "\n")
        stream.flush()
    print("[" + datetime.now().strftime("%H:%M:%S") + "] " + event + " " +
          " ".join(f"{k}={v}" for k, v in items.items()), flush=True)


def scores_from_calibration(losses, penalty=0.25):
    scores = {}
    for method in METHODS:
        x = np.asarray(losses[method], dtype=float)
        if x.size == 0 or not np.isfinite(x).all():
            raise ValueError("Calibration losses must be complete and finite")
        mean = float(x.mean())
        std = float(x.std(ddof=1)) if len(x) > 1 else 0.0
        cv = std / mean if mean > 1e-12 else 0.0
        scores[method] = mean * (1 + penalty * cv)
    return scores


def choose_tasca(losses, raw_width, threshold=32, penalty=0.25, margin=0.05):
    scores = scores_from_calibration(losses, penalty)
    best = min(METHODS, key=lambda m: (scores[m], m))
    non = min((T, N), key=lambda m: (scores[m], m))
    if best == C and (scores[non] - scores[C]) / max(scores[non], 1e-12) < margin:
        best = non
    return T if raw_width >= threshold else best


def choose_policies(losses, raw_width, retained_width):
    choices = {m: m for m in METHODS}
    choices.update({
        "TASCA": choose_tasca(losses, raw_width),
        "width_only": T if raw_width >= 32 else N,
        "TASCA_no_width_guard": choose_tasca(losses, raw_width, threshold=float("inf")),
        "TASCA_retained_width_guard": choose_tasca(losses, retained_width),
        "calibration_argmin": min(METHODS, key=lambda m: (float(np.mean(losses[m])), m)),
        "TASCA_no_dispersion": choose_tasca(losses, raw_width, penalty=0.0),
        "TASCA_no_source_margin": choose_tasca(losses, raw_width, margin=0.0),
        "persistence": "persistence",
    })
    for threshold in (24, 48, 64, 96):
        choices[f"TASCA_threshold_{threshold}"] = choose_tasca(losses, raw_width, threshold=threshold)
    return choices


def freeze_protocol(tasks, audit):
    manifest = independent_manifest()
    for row in manifest:
        if sha256(row["file"]) != row["sha256"]:
            raise RuntimeError("Raw data hash mismatch: " + row["file"])
    protocol = {
        "version": "frozen_tasca_v1", "model_directory": str(MODEL),
        "library_versions": {p: importlib.metadata.version(p) for p in ("torch", "chronos-forecasting", "numpy", "pandas", "transformers")},
        "inference_settings": {"dtype": "float32", "batch_size": 1, "cross_learning": True, "quantile": 0.5, "seed": 42},
        "model_sha256": sha256(MODEL / "model.safetensors"),
        "model_config_sha256": sha256(MODEL / "config.json"),
        "datasets": [{k: r[k] for k in ("file", "url", "sha256")} for r in manifest],
        "context": CONTEXT, "horizon": HORIZON, "native_budgets": list(BUDGETS),
        "source_budget": SOURCE_BUDGET, "primary_budget": 24,
        "defaults": {"raw_width_threshold": 32, "dispersion_penalty": 0.25, "source_margin": 0.05},
        "primary_endpoint": "Equal collection-weighted mean standardized target MSE; first average targets and two chronological blocks inside each collection.",
        "primary_comparisons": [N, T, C, "width_only", "TASCA_no_width_guard", "calibration_argmin"],
        "preprocessing": "Causal ffill; leading prefix only removed; no backward fill; first 70 percent for scaling and native/source variance ranking; missing labels masked.",
        "window_protocol": "Two consecutive disjoint 15 percent blocks; first 6/16 for 6 calibration windows, remaining 10/16 for 10 test windows; nonoverlapping labels; minimum 18 observed values per horizon.",
        "sensitivity_only_thresholds": [24, 32, 48, 64, 96],
        "test_data_policy": "No rule tuning or outcome-based dataset removal; all registered tasks reported. New datasets are held out from TASCA development, not proven absent from TSFM pretraining.",
        "tasks": [{k: t[k] for k in ("task", "dataset", "family", "target", "source", "raw_width", "native_rank", "source_rank", "windows", "alignment", "target_scale_mean", "target_scale_std")} for t in tasks],
        "data_audit": json.loads(audit.to_json(orient="records")),
    }
    for metadata, task in zip(protocol["tasks"], tasks):
        digest = hashlib.sha256()
        for key in ("target_frame", "source_frame"):
            digest.update(canonical(list(task[key].columns)).encode())
            digest.update(task[key].to_numpy(dtype=np.float32).tobytes())
        digest.update(task["observed"].tobytes())
        metadata["prepared_values_sha256"] = digest.hexdigest()
    serialized = canonical(protocol)
    fingerprint = hashlib.sha256(serialized.encode()).hexdigest()
    path = RESULTS / "frozen_protocol.json"
    if path.exists():
        previous = json.loads(path.read_text(encoding="utf-8"))
        if previous["fingerprint"] != fingerprint:
            raise RuntimeError("Frozen protocol changed. Preserve this run and use a new version directory.")
    else:
        atomic_text(path, json.dumps({"frozen_at_utc": now(), "fingerprint": fingerprint, "protocol": protocol}, indent=2))
    atomic_text(RESULTS / "data_audit.csv", audit.to_csv(index=False))
    return fingerprint, protocol["model_sha256"]


class Store:
    def __init__(self):
        self.db = sqlite3.connect(RESULTS / "forecast_cache.sqlite")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS predictions (key TEXT PRIMARY KEY, payload TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS windows (key TEXT PRIMARY KEY, payload TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS decisions (key TEXT PRIMARY KEY, payload TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS cases (key TEXT PRIMARY KEY, payload TEXT NOT NULL)")
        self.db.commit()

    def get(self, table, key):
        row = self.db.execute(f"SELECT payload FROM {table} WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def put(self, table, key, value):
        data = canonical(value)
        self.db.execute(f"INSERT OR REPLACE INTO {table} VALUES (?,?)", (key, data))
        self.db.commit()

    def frame(self, table):
        return pd.DataFrame([json.loads(row[0]) for row in self.db.execute(f"SELECT payload FROM {table} ORDER BY key")])

    def close(self):
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.db.close()


class Forecaster:
    def __init__(self, store, model_hash):
        self.store = store
        self.model_hash = model_hash
        self.pipeline = None
        self.calls = 0
        self.hits = 0

    def load(self):
        import torch
        from chronos import Chronos2Pipeline
        if not torch.cuda.is_available():
            raise RuntimeError("This registered run requires the available CUDA GPU; no silent CPU fallback.")
        torch.set_num_threads(4)
        torch.manual_seed(42)
        np.random.seed(42)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        started = time.perf_counter()
        self.pipeline = Chronos2Pipeline.from_pretrained(str(MODEL), device_map="cuda", local_files_only=True)
        self.pipeline.model.eval()
        self.median_index = list(self.pipeline.quantiles).index(0.5)
        self.torch = torch
        versions = {p: importlib.metadata.version(p) for p in ("torch", "chronos-forecasting", "numpy", "pandas", "transformers")}
        log("model_loaded", gpu=torch.cuda.get_device_name(0), seconds=round(time.perf_counter() - started, 2))
        atomic_text(RESULTS / "environment.json", json.dumps({"python": sys.executable, "versions": versions,
                    "gpu": torch.cuda.get_device_name(0), "model_sha256": self.model_hash,
                    "model_dtype": str(next(self.pipeline.model.parameters()).dtype)}, indent=2))
        # Verify the tensor path against the dataframe interface used by the paper.
        x = np.vstack([np.sin(np.arange(CONTEXT) / 7), np.cos(np.arange(CONTEXT) / 9), np.arange(CONTEXT) / 100]).astype(np.float32)
        tensor_pred = self.raw_predict(x)
        df = pd.DataFrame(x.T, columns=["y0", "y1", "y2"])
        df.insert(0, "timestamp", pd.date_range("2000-01-01", periods=CONTEXT, freq="h"))
        df.insert(0, "id", "interface_check")
        with torch.inference_mode():
            pred = self.pipeline.predict_df(df, prediction_length=HORIZON, quantile_levels=[0.5],
                    id_column="id", timestamp_column="timestamp", target=["y0", "y1", "y2"],
                    batch_size=1, context_length=CONTEXT, cross_learning=True, freq="h")
        actual = pred.loc[pred.target_name == "y0", "0.5"].to_numpy()
        difference = float(np.max(np.abs(actual - tensor_pred)))
        if difference > 1e-5:
            raise RuntimeError("Tensor/dataframe parity check failed")
        atomic_text(RESULTS / "interface_parity.json", canonical({"synthetic_check_only": True, "max_abs_difference": difference}))
        log("interface_parity_passed", max_abs_difference=difference)

    def raw_predict(self, x):
        with self.torch.inference_mode():
            output = self.pipeline.predict([np.ascontiguousarray(x)], prediction_length=HORIZON,
                       context_length=CONTEXT, batch_size=1, cross_learning=True)[0]
        return output[0, self.median_index].cpu().numpy().astype(float)

    def predict(self, x):
        x = np.ascontiguousarray(x, dtype=np.float32)
        digest = hashlib.sha256(self.model_hash.encode() + canonical([list(x.shape), CONTEXT, HORIZON]).encode() + x.tobytes()).hexdigest()
        cached = self.store.get("predictions", digest)
        if cached:
            self.hits += 1
            return np.array(cached["prediction"]), digest, 0.0, True
        if self.pipeline is None:
            self.load()
        started = time.perf_counter()
        prediction = self.raw_predict(x)
        duration = time.perf_counter() - started
        if prediction.shape != (HORIZON,) or not np.isfinite(prediction).all():
            raise RuntimeError("Invalid model output")
        self.store.put("predictions", digest, {"prediction": prediction.tolist(), "shape": list(x.shape),
                         "elapsed_seconds": duration, "created_utc": now(), "model_sha256": self.model_hash})
        self.calls += 1
        return prediction, digest, duration, False


def evaluate_window(task, budget, window, method, backend, store):
    key = canonical([task["task"], budget, window["replication"], window["split"], window["window"], method])
    old = store.get("windows", key)
    if old:
        return old
    origin = window["origin"]
    native = task["native_rank"][:budget]
    sources = task["source_rank"]
    target = task["target_frame"][task["target"]].to_numpy()
    true = target[origin:origin + HORIZON].astype(float)
    mask = task["observed"][origin:origin + HORIZON]
    if method == "persistence":
        prediction = np.full(HORIZON, target[origin - 1])
        digest, duration, cached = "persistence", 0.0, False
        count = 1
    else:
        selected = [task["target"]] if method == T else native
        x = task["target_frame"][selected].iloc[origin - CONTEXT:origin].to_numpy().T
        if method == C:
            sx = task["source_frame"][sources].iloc[origin - CONTEXT:origin].to_numpy().T
            x = np.concatenate([x, sx], axis=0)
        count = x.shape[0]
        prediction, digest, duration, cached = backend.predict(x)
    error = prediction[mask] - true[mask]
    row = {"key": key, "task": task["task"], "dataset": task["dataset"], "family": task["family"],
           "target": task["target"], "source": task["source"], "alignment": task["alignment"],
           "raw_width": task["raw_width"], "budget": budget, "native_used": len(native),
           "forecast_timestamp": str(task["target_frame"].index[origin]),
           "source_used": len(sources), "method": method, **window, "input_channels": count,
           "mse": float(np.mean(error ** 2)), "mae": float(np.mean(np.abs(error))),
           "prediction": prediction.tolist(), "truth": true.tolist(), "observed_mask": mask.tolist(),
           "cache_key": digest, "inference_seconds": duration, "cached_prediction": cached}
    store.put("windows", key, row)
    return row


def run_case(task, budget, rep, backend, store):
    windows = [w for w in task["windows"] if w["replication"] == rep]
    cal = {m: [] for m in METHODS}
    for window in [w for w in windows if w["split"] == "calibration"]:
        for method in METHODS:
            cal[method].append(evaluate_window(task, budget, window, method, backend, store)["mse"])
    choices = choose_policies(cal, task["raw_width"], min(budget, len(task["native_rank"])))
    case_key = canonical([task["task"], budget, rep])
    decision = {"task": task["task"], "budget": budget, "replication": rep,
                "calibration_losses": cal, "scores": scores_from_calibration(cal), "choices": choices}
    previous = store.get("decisions", case_key)
    if previous and canonical(previous) != canonical(decision):
        raise RuntimeError("Stored calibration decision changed")
    store.put("decisions", case_key, decision)
    # Test labels become available to evaluation only after the decision is stored.
    test = {m: [] for m in (*METHODS, "persistence")}
    for window in [w for w in windows if w["split"] == "test"]:
        for method in test:
            test[method].append(evaluate_window(task, budget, window, method, backend, store))
    choices["oracle_three_contexts"] = min(METHODS, key=lambda m: (np.mean([r["mse"] for r in test[m]]), m))
    for policy, method in choices.items():
        rows = test[method]
        record = {"task": task["task"], "dataset": task["dataset"], "family": task["family"],
                  "target": task["target"], "source": task["source"], "raw_width": task["raw_width"],
                  "budget": budget, "native_used": min(budget, len(task["native_rank"])),
                  "replication": rep, "policy": policy, "selected_method": method,
                  "mse": float(np.mean([r["mse"] for r in rows])),
                  "mae": float(np.mean([r["mae"] for r in rows])),
                  "test_windows": len(rows), "observed_labels": sum(r["observed_labels"] for r in rows),
                  "diagnostic_only": policy == "oracle_three_contexts"}
        store.put("cases", canonical([task["task"], budget, rep, policy]), record)


def export_reports(store, expected_cases, complete=False):
    cases = store.frame("cases")
    if cases.empty:
        return
    atomic_text(RESULTS / "case_results.csv", cases.to_csv(index=False))
    family = cases.groupby(["budget", "family", "policy"], as_index=False).agg(mse=("mse", "mean"), mae=("mae", "mean"), cases=("mse", "count"))
    atomic_text(RESULTS / "family_results.csv", family.to_csv(index=False))
    overall = family.groupby(["budget", "policy"], as_index=False).agg(mse=("mse", "mean"), mae=("mae", "mean"), families=("family", "nunique"))
    overall = overall.sort_values(["budget", "mse"])
    atomic_text(RESULTS / "macro_results.csv", overall.to_csv(index=False))
    primary = family[family.budget == 24].pivot(index="family", columns="policy", values="mse")
    comparisons = []
    rng = np.random.default_rng(SEED)
    indices = rng.integers(0, len(primary), size=(10000, len(primary)))
    for baseline in [N, T, C, "width_only", "TASCA_no_width_guard", "calibration_argmin", "persistence"]:
        differences = (primary.TASCA - primary[baseline]).to_numpy()
        samples = differences[indices].mean(axis=1)
        lo, hi = np.quantile(samples, [0.025, 0.975])
        base = float(primary[baseline].mean())
        comparisons.append({"baseline": baseline, "tasca_macro_mse": float(primary.TASCA.mean()),
                            "baseline_macro_mse": base, "difference": float(differences.mean()),
                            "relative_improvement_percent": 100 * (base - primary.TASCA.mean()) / base,
                            "family_bootstrap_ci_low": float(lo), "family_bootstrap_ci_high": float(hi),
                            "family_wins": int((differences < -1e-12).sum()),
                            "family_ties": int((np.abs(differences) <= 1e-12).sum()),
                            "family_losses": int((differences > 1e-12).sum()),
                            "families": len(primary)})
    atomic_text(RESULTS / "primary_comparisons.csv", pd.DataFrame(comparisons).to_csv(index=False))
    loo = []
    for excluded in primary.index:
        keep = primary.drop(index=excluded)
        for baseline in [N, T, "width_only"]:
            loo.append({"excluded_family": excluded, "baseline": baseline,
                        "tasca_mse": float(keep.TASCA.mean()), "baseline_mse": float(keep[baseline].mean()),
                        "difference": float((keep.TASCA - keep[baseline]).mean())})
    atomic_text(RESULTS / "leave_one_family_out.csv", pd.DataFrame(loo).to_csv(index=False))
    counts = cases.groupby(["budget", "policy", "selected_method"], as_index=False).size()
    atomic_text(RESULTS / "selection_counts.csv", counts.to_csv(index=False))
    completed = cases[["task", "budget", "replication"]].drop_duplicates().shape[0]
    status = {"complete": complete, "completed_cases": completed, "expected_cases": expected_cases,
              "forecasts_cached": store.db.execute("SELECT COUNT(*) FROM predictions").fetchone()[0],
              "window_records": store.db.execute("SELECT COUNT(*) FROM windows").fetchone()[0], "updated_utc": now()}
    if complete and (completed != expected_cases or len(primary) != 5):
        raise AssertionError("Run is incomplete; no final success state permitted")
    atomic_text(RESULTS / "status.json", json.dumps(status, indent=2))
    if complete:
        windows = store.frame("windows")
        scalar_cols = [c for c in windows if c not in {"prediction", "truth", "observed_mask"}]
        atomic_text(RESULTS / "window_metrics.csv", windows[scalar_cols].to_csv(index=False))
        with (RESULTS / "predictions.jsonl").open("w", encoding="utf-8") as stream:
            for row in windows.to_dict(orient="records"):
                stream.write(canonical(row) + "\n")
        text = ["# Frozen TASCA: independent-data validation", "", "Status: COMPLETE", "",
                "Primary: native cap 24, source cap 24, context 96, horizon 24; equal dataset-collection weighting.",
                "Two disjoint chronological blocks per task; six calibration and ten test windows each.",
                "Frozen width threshold 32, penalty 0.25, margin 0.05. No test-driven tuning.", "",
                "## Primary macro results", "", "| Policy | MSE | MAE |", "|---|---:|---:|"]
        for _, row in overall[overall.budget == 24].iterrows():
            text.append(f"| {row.policy} | {row.mse:.6f} | {row.mae:.6f} |")
        text += ["", "## Dataset-family results", "", "| Family | TASCA | Native | Target-only | Width-only | No guard |", "|---|---:|---:|---:|---:|---:|"]
        for name, row in primary.iterrows():
            text.append(f"| {name} | {row.TASCA:.6f} | {row[N]:.6f} | {row[T]:.6f} | {row.width_only:.6f} | {row.TASCA_no_width_guard:.6f} |")
        text += ["", "## Interpretation constraints", "",
                 "- Held out from TASCA development, not established as unseen by Chronos-2 pretraining.",
                 "- Beijing is a new collection in a previously studied air-quality domain; report it separately.",
                 "- Non-Beijing cross-domain inputs are row-aligned heterogeneous-pattern controls, not physically synchronized exogenous variables.",
                 "- HAI is a normal-operation HIL-augmented industrial testbed, not an industrial field deployment.",
                 "- Only five collection clusters; bootstrap intervals are descriptive and have limited calibration. Several collections share source datasets.",
                 "- Threshold alternatives are prespecified sensitivity diagnostics, not candidates for selecting a new winner on this holdout.",
                 "- Multiple targets and temporal blocks are averaged within a collection before cross-collection summaries.", ""]
        atomic_text(RESULTS / "RESULTS.md", "\n".join(text))


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    log("preparing_outcome_blind_data")
    tasks, audit = build_tasks(load_datasets())
    fingerprint, model_hash = freeze_protocol(tasks, audit)
    expected = len(tasks) * len(BUDGETS) * 2
    log("protocol_locked", tasks=len(tasks), cases=expected, fingerprint=fingerprint[:16])
    snapshots = RESULTS / "code_snapshots"
    snapshots.mkdir(exist_ok=True)
    for name in ("independent_validation.py", "data_protocol.py"):
        source = ROOT / name
        dest = snapshots / (sha256(source)[:16] + "_" + name)
        if not dest.exists():
            shutil.copy2(source, dest)
    store = Store()
    backend = Forecaster(store, model_hash)
    completed = 0
    try:
        # Finish the primary budget first; all sensitivity budgets remain registered.
        for budget in (24, 8, 16, 48):
            for task in tasks:
                for rep in (0, 1):
                    run_case(task, budget, rep, backend, store)
                    completed += 1
                    export_reports(store, expected)
                    log("case_complete", case=completed, total=expected, task=task["task"],
                        budget=budget, replication=rep, new_model_calls=backend.calls, prediction_cache_hits=backend.hits)
        export_reports(store, expected, complete=True)
        integrity = store.db.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError("SQLite integrity failed")
        elapsed = time.perf_counter() - started
        log("completed", seconds=round(elapsed, 2), new_model_calls=backend.calls,
            prediction_cache_hits=backend.hits, database_integrity=integrity)
        atomic_text(RESULTS / "last_execution.json", canonical({"seconds": elapsed, "new_model_calls": backend.calls,
                    "prediction_cache_hits": backend.hits, "complete": True, "utc": now()}))
        print("\n" + (RESULTS / "RESULTS.md").read_text(encoding="utf-8"), flush=True)
    except BaseException as exc:
        log("interrupted_or_failed", error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        store.close()


if __name__ == "__main__":
    main()
