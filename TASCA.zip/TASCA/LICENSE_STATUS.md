# Permission before public release

No open-source license has been assigned by this packaging step. The authors and, where required, their institution must authorize distribution and choose an appropriate license before public GitHub publication. This notice is not an open-source license. Third-party model and dataset licenses continue to apply separately. Do not commit raw datasets, model snapshots, adapters, private configuration, access tokens, review correspondence, or unreleased manuscripts.
