"""Regenerate core target-level estimates from reference or fresh case metrics."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from settings import ROOT

# Set False after completing run_experiments.py to analyze newly generated metrics.
USE_REFERENCE = True


def main():
    folder=ROOT/'reference/core' if USE_REFERENCE else ROOT/'engines/core/corrected_results'
    df=pd.read_csv(folder/'case_results.csv')
    df=df[(df.study=='core') & (df.model=='chronos2') & (df.horizon==24)]
    target=df.groupby(['target','policy']).mse.mean().unstack()
    rows=[]
    for method in target:
        delta=(target.TASCA-target[method]).to_numpy()
        rng=np.random.default_rng(20261019)
        bootstrap=delta[rng.integers(0,len(delta),(20000,len(delta)))].mean(axis=1)
        lo,hi=np.quantile(bootstrap,[.025,.975])
        rows.append(dict(policy=method,mse=target[method].mean(),tasca_minus_method=delta.mean(),ci_low=lo,ci_high=hi,
                         wins=int((delta < -1e-12).sum()),ties=int((abs(delta)<=1e-12).sum()),losses=int((delta>1e-12).sum())))
    out=ROOT/'outputs/tables'
    out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(out/'core_target_macro.csv',index=False)
    target.to_csv(out/'core_per_target.csv')
    if USE_REFERENCE:
        np.testing.assert_allclose(target.TASCA.mean(),.23217054161938605,rtol=1e-12)
        np.testing.assert_allclose(target.native_all.mean(),.2603893558905769,rtol=1e-12)
    print('Core target macro MSE:',target[['TASCA','native_all']].mean().to_dict())
    print('Source:',folder)
    print('Extension and synchronized collection-level tables are produced by their respective experiment engines.')


if __name__=='__main__':
    main()
