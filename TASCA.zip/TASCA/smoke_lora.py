"""Real 100-step LoRA fits for one pair; isolated from full benchmark outputs."""
import json
import sys
from settings import ROOT
sys.path.insert(0,str(ROOT/'engines/core'))
import corrected_benchmark as core
import corrected_lora as lora


class OnePair(core.Data):
    def __init__(self):
        super().__init__()
        self.pairs=[('ETTh1','ETTh2')]


def main():
    core.OUT=ROOT/'outputs/lora_smoke/frozen'
    core.OUT.mkdir(parents=True,exist_ok=True)
    core.data=OnePair()
    store=core.Store()
    try:
        backend=core.Backend('chronos2',store)
        core.run_case(core.data.pair('ETTh1','ETTh2'),'original',24,backend,store,'core')
        core.summarize(store)
        del backend
    finally:
        store.close()
    (core.OUT/'completion.json').write_text(json.dumps(dict(complete=True,scope='one-pair smoke only')))
    lora.OUT=core.OUT
    lora.DEST=ROOT/'outputs/lora_smoke/adaptation'
    lora.Data=OnePair
    lora.main()
    print('One-pair LoRA smoke completed; this is not the 22-pair result.')


if __name__=='__main__':
    main()
