"""Build a sanitized release ZIP; does not create or push a GitHub repository."""
import hashlib
import json
from pathlib import Path
import re
import zipfile
from settings import ROOT


def public_files():
    files=list(ROOT.glob('*.py'))+list(ROOT.glob('*.md'))+list(ROOT.glob('*.txt'))
    files += [ROOT/'.gitignore',ROOT/'PROVENANCE.json']
    files += list((ROOT/'datasets').glob('*_manifest.json'))
    files += list((ROOT/'engines').glob('*/*.py'))
    files += [ROOT/'engines/core/windows.csv', ROOT/'engines/synchronized/protocols/REVISION_PROTOCOL.md']
    files += list((ROOT/'reference').rglob('*.csv'))
    files += list((ROOT/'verification').glob('*.json'))
    return sorted(set(files))


def main():
    entries={}
    for path in public_files():
        content=path.read_bytes()
        if re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',content,re.I) or re.search(rb'hf_[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}',content):
            raise ValueError('Potential private path or token: '+str(path.relative_to(ROOT)))
        entries[str(path.relative_to(ROOT)).replace('\\','/')]=content
    manifest={name:hashlib.sha256(content).hexdigest() for name,content in entries.items()}
    entries['RELEASE_SHA256.json']=json.dumps(manifest,indent=2).encode()
    out=ROOT.parent/'TASCA_Reproduction_GitHub.zip'
    tmp=out.with_suffix('.tmp')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,content in entries.items():
            archive.writestr('TASCA/'+name,content)
    with zipfile.ZipFile(tmp) as archive:
        assert archive.testzip() is None
    tmp.replace(out)
    print(f'Packaged {len(entries)} files: {out}')
    print('Excluded: local configuration, raw data, models, adapters, live caches and generated outputs.')


if __name__=='__main__':
    main()
