"""Frozen TASCA selector; calibration losses only, no test labels."""
import numpy as np
T,N,C="target_univariate","native_all","cross_all"
BASE=(T,N,C)

def score(losses, penalty=.25):
    x = np.asarray(losses, dtype=float)
    assert len(x) and np.isfinite(x).all()
    mean = float(x.mean())
    sd = float(x.std(ddof=1)) if len(x)>1 else 0.
    return mean + penalty*sd if mean>1e-12 else mean

def choose(losses, width, penalty=.25, margin=.05, threshold=32, source=True):
    if width >= threshold:
        return T
    s = {m: score(losses[m], penalty) for m in BASE}
    non = min((T, N), key=lambda m:(s[m],m))
    best = min(BASE, key=lambda m:(s[m],m)) if source else non
    return non if best==C and (s[non]-s[C])/max(s[non],1e-12)<margin else best

def policies(losses, width):
    out = {m:m for m in BASE}
    out.update(TASCA=choose(losses,width), width_only=T if width>=32 else N,
               no_width_guard=choose(losses,width,threshold=float("inf")),
               no_dispersion=choose(losses,width,penalty=0),
               no_source_margin=choose(losses,width,margin=0),
               non_source_only=choose(losses,width,source=False),
               calibration_argmin=min(BASE,key=lambda m:(np.mean(losses[m]),m)))
    cv = {m:float(np.std(losses[m],ddof=1)/(np.mean(losses[m])+1e-12)) if len(losses[m])>1 else 0 for m in BASE}
    available = [m for m in BASE if cv[m]<=1] or list(BASE)
    out["calibration_cv"] = min(available,key=lambda m:(np.mean(losses[m]),m))
    for th in (24,48,64,96):
        out[f"threshold_{th}"] = choose(losses,width,threshold=th)
    for penalty in (.10,.20,.30,.50):
        out[f"penalty_{penalty:.2f}"] = choose(losses,width,penalty=penalty)
    for margin in (.02,.04,.06,.10):
        out[f"margin_{margin:.2f}"] = choose(losses,width,margin=margin)
    for k in (1,2,3,4):
        out[f"calibration_first_{k}"] = choose({m:losses[m][:k] for m in BASE},width)
    return out
