"""Open in PyCharm and Run. Reuse durable caches after interruptions."""
import json
import importlib.metadata
import os
import subprocess
import sys
from pathlib import Path
from settings import ROOT, core_path, sha256, model_path

# Full paper workflow. Set a subset to run only that study.
STUDIES = ('core', 'independent', 'synchronized', 'lora')
SCRIPTS = {'core': 'core/corrected_benchmark.py',
           'lora': 'core/corrected_lora.py',
           'independent': 'independent/independent_validation.py',
           'synchronized': 'synchronized/run_synchronized_evaluation.py'}


def main():
    env = dict(os.environ, PYTHONPATH=str(ROOT), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    for study in STUDIES:
        if study in ('core','lora'):
            manifest = json.loads((ROOT/'datasets/core_manifest.json').read_text())
            for name, meta in manifest.items():
                path = core_path(name)
                if not Path(path).exists():
                    raise FileNotFoundError(f'{name}: provide {path}; see DATASETS.md')
                if sha256(path) != meta['sha256']:
                    raise ValueError(f'Raw data differ from the frozen experiment: {name}')
        script = ROOT/'engines'/SCRIPTS[study]
        guard = script.parent/('.'+study+'_run_identity.json')
        code = list(ROOT.glob('*.py')) + list((ROOT/'engines').glob('*/*.py'))
        identity = {str(p.relative_to(ROOT)): sha256(p) for p in sorted(code)}
        identity['package_versions']={name:importlib.metadata.version(name) for name in ('torch','chronos-forecasting','numpy','pandas','transformers','uni2ts','peft')}
        for name in (('chronos-2','moirai-2.0-r-small') if study=='core' else ('chronos-2',)):
            for file in ('model.safetensors','config.json'):
                identity[name+'/'+file] = sha256(model_path(name)/file)
        if guard.exists() and json.loads(guard.read_text()) != identity:
            raise RuntimeError('Code or model changed. Preserve outputs and start a separate clean repository copy.')
        temporary=guard.with_suffix('.tmp')
        temporary.write_text(json.dumps(identity,indent=2))
        temporary.replace(guard)
        print('Starting '+study, flush=True)
        subprocess.run([sys.executable,str(script)],cwd=script.parent,env=env,check=True)
    print('All selected workflows completed. Run reproduce_tables.py to rebuild the core table.')


if __name__ == '__main__':
    main()
