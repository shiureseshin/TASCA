"""Reproduce manuscript result figures. PyCharm/freqrank_clean: click Run."""
from pathlib import Path
import hashlib
import json
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, ListedColormap
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "reference/figure_inputs"
OUT = ROOT / "outputs" / "result_figures"
ASSETS = ROOT / "outputs" / "manuscript_figures"
SYNC_RESULTS = ROOT / "reference/synchronized"
CACHED_RESULTS = ROOT / "reference/cached_analysis"
T, N, C = "target_univariate", "native_all", "cross_all"
COLORS = {T: "#2476A5", N: "#168477", C: "#B76A19", "loss": "#B94647"}
STYLE = {"font.family": "Arial", "font.size": 8, "axes.labelsize": 8,
         "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
         "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6,
         "xtick.major.width": 0.6, "ytick.major.width": 0.6,
         "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
         "savefig.facecolor": "white", "savefig.bbox": None}
PAIRS = ["ETTh1<-ETTh2", "ETTh1<-weather", "ETTh2<-ETTh1", "ETTh2<-weather",
         "ETTm1<-ETTm2", "ETTm2<-ETTm1", "ETTm2<-exchange_rate", "ETTm2<-weather",
         "PRSA<-weather", "Solar_Energy<-weather", "electricity<-exchange_rate",
         "electricity<-traffic", "electricity<-weather", "exchange_rate<-ETTm2",
         "exchange_rate<-Solar_Energy", "exchange_rate<-electricity", "traffic<-electricity",
         "weather<-ETTh2", "weather<-ETTm2", "weather<-PRSA", "weather<-Solar_Energy",
         "weather<-electricity"]
REPS = ["original", "phase_shifted", "late_phase"]
FILES = []


def save(fig, stem, description):
    fig.canvas.draw()
    # Text outside the physical canvas is a hard failure, not an invisible crop.
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(matplotlib.text.Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < -2 or box.y0 < -2 or box.x1 > fig.bbox.width + 2 or box.y1 > fig.bbox.height + 2:
            raise AssertionError("Out-of-canvas text: " + text.get_text())
    for suffix in ("pdf", "svg", "png"):
        file = OUT / (stem + "." + suffix)
        fig.savefig(file, dpi=600 if suffix == "png" else 300)
        FILES.append({"file": str(file.relative_to(ROOT)), "sha256": hashlib.sha256(file.read_bytes()).hexdigest()})
    shutil.copy2(OUT / (stem + ".pdf"), ASSETS / (stem + ".pdf"))
    (OUT / (stem + "_description.txt")).write_text(description, encoding="utf-8")
    plt.close(fig)


def display_pair(pair):
    return pair.replace("<-", " ← ").replace("exchange_rate", "Exchange").replace("Solar_Energy", "Solar").replace("electricity", "Electricity").replace("traffic", "Traffic").replace("weather", "Weather")


def pair_figure(core):
    p = core.pivot(index=["pair", "replication"], columns="policy", values="mse")
    gains = (100 * (1 - p["TASCA"] / p[N])).unstack().loc[PAIRS, REPS]
    choices = core[core.policy == "TASCA"].pivot(index="pair", columns="replication", values="selected").loc[PAIRS, REPS]
    assert gains.shape == (22, 3) and np.isfinite(gains.to_numpy()).all()
    assert gains.abs().to_numpy().max() < 40
    gains.to_csv(OUT / "pair_relative_gains.csv")
    choices.to_csv(OUT / "pair_context_choices.csv")
    fig = plt.figure(figsize=(180 / 25.4, 132 / 25.4))
    left = fig.add_axes([0.265, 0.19, 0.34, 0.73])
    right = fig.add_axes([0.70, 0.19, 0.25, 0.73])
    im = left.imshow(gains.to_numpy(), cmap="RdBu", norm=TwoSlopeNorm(vmin=-40, vcenter=0, vmax=40), aspect="auto")
    codes = choices.apply(lambda column: column.map({T: 0, N: 1, C: 2})).to_numpy(dtype=int)
    right.imshow(codes, cmap=ListedColormap([COLORS[T], COLORS[N], COLORS[C]]), vmin=-0.5, vmax=2.5, aspect="auto")
    for ax in (left, right):
        ax.set_xticks(range(3), ["Original", "Shifted", "Late"])
        ax.xaxis.tick_top()
        ax.tick_params(axis="both", length=0, pad=4)
        ax.set_yticks(np.arange(-0.5, 22, 1), minor=True)
        ax.grid(axis="y", which="minor", color="white", linewidth=0.5)
        ax.tick_params(which="minor", length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
    left.set_yticks(range(22), [display_pair(p) for p in PAIRS])
    right.set_yticks([])
    for i in range(1,len(PAIRS)):
        if PAIRS[i].split('<-')[0] != PAIRS[i-1].split('<-')[0]:
            for ax in (left,right):
                ax.axhline(i-.5,color='#58666D',linewidth=.7)
    for i in range(22):
        for j in range(3):
            value = gains.iloc[i, j]
            left.text(j, i, f"{value:+.1f}" if abs(value) >= .05 else "0.0", ha="center", va="center", fontsize=7,
                      color="white" if abs(value) > 25 else "#20272D")
            right.text(j, i, ["T", "N", "S"][codes[i, j]], ha="center", va="center", color="white", fontsize=7.5, weight="bold")
    fig.text(.435, .135, "(a) MSE reduction vs native-all (%)", ha="center", fontsize=8)
    fig.text(.825, .135, "(b) Selected context", ha="center", fontsize=8)
    bar_ax = fig.add_axes([.30, .055, .27, .022])
    bar = fig.colorbar(im, cax=bar_ax, orientation="horizontal", ticks=[-40, -20, 0, 20, 40])
    bar.ax.tick_params(labelsize=7, length=2)
    fig.text(.825, .067, "T  Target-only   N  Native\nS  Source-augmented", ha="center", va="center", fontsize=7)
    save(fig, "pair_context_map", "All 22 target-source pairs and all three temporal placements. Panel (a) is 100*(1-MSE_TASCA/MSE_native) within each case: blue positive values improve on native, red negative values worsen it. It is not the ratio of overall mean errors. Panel (b) gives the actual chosen context. No cases omitted, no color clipping, no uncertainty intervals inferred.")


def component_figure(core, independent):
    policies = ["TASCA", "no_width_guard", "no_dispersion", "no_source_margin", "non_source_only", "width_only"]
    names = ["TASCA", "No width guard", "No dispersion", "No source margin", "Non-source only", "Width-only rule"]
    means = core.groupby("policy").mse.mean().loc[policies]
    means.to_csv(OUT / "component_mse.csv", header=True)
    a = core[core.policy == "TASCA"].selected.value_counts().reindex([T, N, C], fill_value=0)
    b = independent[(independent.budget == 24) & (independent.policy == "TASCA")].selected_method.value_counts().reindex([T, N, C], fill_value=0)
    assert a.tolist() == [37, 16, 13] and b.tolist() == [21, 7, 0]
    pd.DataFrame({"core": a, "additional": b}).to_csv(OUT / "selection_counts.csv")
    fresh=pd.read_csv(SYNC_RESULTS/'case_results.csv')
    d=fresh[(fresh.policy=='TASCA')&(fresh.condition=='full_weather')].selected.value_counts().reindex([T,N,C],fill_value=0)
    assert int(d.sum())==16 and int(d[C])==7
    pd.DataFrame({'core':a,'additional':b,'synchronized':d}).to_csv(OUT/'selection_counts.csv')
    fig = plt.figure(figsize=(180 / 25.4, 84 / 25.4))
    left = fig.add_axes([.18, .27, .31, .64])
    left.axvline(means.iloc[0], color="#88939C", linewidth=.8, linestyle="--")
    for i, value in enumerate(means):
        left.plot([means.iloc[0], value], [i, i], color="#BBC3C8", linewidth=1.5)
        left.scatter(value, i, s=25, marker="D" if i == 0 else "o", color=COLORS[N] if i == 0 else "#52626C", zorder=3)
        left.text(value + .00065, i, f"{value:.4f}", va="center", fontsize=7)
    left.set_yticks(range(6), names)
    left.invert_yaxis()
    left.set_xlim(.190, .210)
    left.set_ylim(5.65, -.65)
    left.set_xticks([.190, .200, .210])
    left.set_xlabel("Mean MSE (lower is better)")
    left.tick_params(axis="y", length=0)
    right = fig.add_axes([.64, .27, .33, .64])
    positions = [0, 1, 2]
    starts = np.zeros(3)
    hatches = ["", "//", "xx"]
    for k, method in enumerate([T, N, C]):
        counts = np.array([a[method], b[method], d[method]])
        values = 100 * counts / np.array([66, 28, 16])
        right.barh(positions, values, left=starts, height=.42, color=COLORS[method], edgecolor="white", linewidth=.6, hatch=hatches[k])
        for i, v in enumerate(values):
            if v > 0:
                right.text(starts[i] + v / 2, i, str(counts[i]), ha="center", va="center", color="white", weight="bold", fontsize=8,
                           bbox={'facecolor':COLORS[method], 'edgecolor':'none', 'pad':1.0})
        starts += values
    right.set_yticks(positions, ["Core\n66 cases", "Additional\n28 cases", "Synchronous\n16 cases"])
    right.invert_yaxis()
    right.set_ylim(2.7, -.7)
    right.set_xlim(0, 100)
    right.set_xticks([0, 50, 100])
    right.set_xlabel("Share of selected contexts (%)")
    right.tick_params(axis="y", length=0)
    handles = [matplotlib.patches.Patch(facecolor=COLORS[m], hatch=h, edgecolor="white", label=l)
               for m, h, l in zip([T,N,C], hatches, ["Target-only", "Native", "Source"])]
    right.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, 1.10), ncol=3, frameon=False,
                 columnspacing=.6, handlelength=1.1, handletextpad=.3, fontsize=7)
    fig.text(.335, .07, "(a) Component contribution", ha="center", fontsize=8)
    fig.text(.805, .07, "(b) Context decisions", ha="center", fontsize=8)
    save(fig, "components_and_decisions", "Panel (a): all six rules in the ablation table, equal-weight mean MSE over 66 pair-placement cases; points are descriptive. Panel (b): exact selected-context counts from three cohorts, including the frozen synchronous primary condition. Different cohorts are not independent repeated trials. Within-bar labels are counts; zero source selections in the five-collection extension are retained in selection_counts.csv and caption.")


def external_figure(families, macro):
    order = ["appliances", "sml2010", "tetouan", "hai20", "beijing_multisite"]
    family = families[families.budget == 24].pivot(index="family", columns="policy", values="mse").loc[order]
    gains = 100 * (1 - family.TASCA / family[N])
    gains.to_csv(OUT / "collection_relative_gains.csv", header=True)
    budget = macro.pivot(index="budget", columns="policy", values="mse").loc[[8, 16, 24, 48], ["TASCA", N, "TASCA_no_width_guard"]]
    budget.to_csv(OUT / "native_budget_mse.csv")
    fig = plt.figure(figsize=(180 / 25.4, 76 / 25.4))
    left = fig.add_axes([.17, .27, .31, .64])
    for i, value in enumerate(gains):
        color = COLORS[N] if value > 0 else COLORS["loss"] if value < 0 else "#777777"
        left.barh(i, value, height=.38, color=color, hatch='//' if value<0 else '')
        if abs(value) < .00001:
            left.scatter(0, i, color="#777777", s=14, marker="D")
        left.text(value + (1 if value >= 0 else -1), i, f"{value:+.2f}%" if value else "0.00%",
                  ha="left" if value >= 0 else "right", va="center", fontsize=7)
    left.axvline(0, color="#747E85", linewidth=.7)
    left.set_yticks(range(5), ["Appliances", "SML2010", "Tetouan", "HAI 20.07", "Beijing multi-site"])
    left.invert_yaxis()
    left.set_xlim(-12, 38)
    left.set_xticks([-10, 0, 10, 20, 30])
    left.set_xlabel("MSE reduction vs native-all (%)")
    left.tick_params(axis="y", length=0)
    right = fig.add_axes([.64, .27, .33, .64])
    for policy, label, color, marker, style in [
        (N, "Native-all", "#7A858C", "s", ":"),
        ("TASCA_no_width_guard", "No width guard", COLORS[C], "^", "--"),
        ("TASCA", "TASCA", COLORS[N], "o", "-")]:
        right.plot(budget.index, budget[policy], label=label, color=color, marker=marker, markersize=4, linewidth=1.2, linestyle=style)
    right.set_xticks([8, 16, 24, 48])
    right.set_xlim(5, 51)
    right.set_ylim(.785, .875)
    right.set_yticks([.79, .81, .83, .85, .87])
    right.set_xlabel("Native-channel cap")
    right.set_ylabel("Collection-macro MSE")
    right.legend(frameon=False, loc="upper center", bbox_to_anchor=(.5, 1.10), ncol=3, columnspacing=.5, handlelength=1.2, fontsize=7)
    fig.text(.325, .07, "(a) Additional collections at cap 24", ha="center", fontsize=8)
    fig.text(.805, .07, "(b) Input-budget sensitivity", ha="center", fontsize=8)
    save(fig, "external_validity", "Panel (a): all five collection means at native cap 24; negative values retain failures. Panel (b): all four prespecified native caps, with source capacity fixed at 24. Collection-macro means weight five families equally. Connecting segments only guide the eye between tested caps. No per-collection intervals are available; none are fabricated. The aggregate cap-24 confidence interval crossing zero remains in the manuscript table and caption.")


def admission_figure():
    old=pd.read_csv(CACHED_RESULTS/'admission_diagnostics.csv')
    fresh=pd.read_csv(SYNC_RESULTS/'admission_diagnostics.csv')
    fresh=fresh[fresh.condition=='full_weather'].rename(columns={'admitted':'source_admitted','source_vs_best_non_gain_pct':'test_gain_vs_best_non_pct'})
    xname='calibration_gain_vs_best_non_pct'; yname='test_gain_vs_best_non_pct'
    limits={}
    for field in [xname,yname]:
        values=np.concatenate([old[field].values,fresh[field].values])
        limits[field]=(np.floor(min(values.min(),0)/10)*10-5,np.ceil(max(values.max(),0)/10)*10+5)
    fig=plt.figure(figsize=(180/25.4,92/25.4))
    axes=[fig.add_axes([.12,.27,.34,.65]),fig.add_axes([.62,.27,.34,.65])]
    for ax,df in zip(axes,[old,fresh]):
        ax.axhline(0,color='#A5ADB2',linewidth=.7);ax.axvline(0,color='#A5ADB2',linewidth=.7)
        for selected,marker,color in [(False,'o',COLORS[T]),(True,'D',COLORS[C])]:
            q=df[df.source_admitted==selected]
            ax.scatter(q[xname],q[yname],marker=marker,s=25,facecolors=color if selected else 'none',edgecolors=color,linewidths=.8,label='Admitted' if selected else 'Rejected')
        ax.set_xlim(*limits[xname]);ax.set_ylim(*limits[yname])
        ax.set_xticks(np.arange(np.ceil(limits[xname][0]/50)*50,limits[xname][1],50))
        ax.set_yticks(np.arange(np.ceil(limits[yname][0]/25)*25,limits[yname][1],25))
        ax.set_xlabel('Calibration source gain (%)');ax.set_ylabel('Test source gain (%)')
        ax.legend(frameon=False,loc='upper left',fontsize=7)
    fig.text(.29,.075,'(a) Development: 66 cases',ha='center',fontsize=8)
    fig.text(.79,.075,'(b) Synchronized: 16 cases',ha='center',fontsize=8)
    pd.concat([old.assign(cohort='development'),fresh.assign(cohort='synchronized')],ignore_index=True).to_csv(OUT/'admission_plot_data.csv',index=False)
    save(fig,'admission_reliability','All development and primary synchronized cases. Both axes are 100*(1-source MSE / min(target MSE,native MSE)) within the indicated split. Shared linear axis limits retain every point. Filled diamonds indicate admission. Points share targets and periods; no independent-case significance inference. Source data in admission_plot_data.csv.')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    cases = pd.read_csv(DATA / "core_case_results.csv")
    core = cases[(cases.study == "core") & (cases.model == "chronos2") & (cases.horizon == 24)]
    assert core[core.policy == "TASCA"].shape[0] == 66
    assert not core.duplicated(["pair", "replication", "policy"]).any()
    means = core.groupby("policy").mse.mean()
    assert np.isclose(means.TASCA, .19154094597865706)
    assert np.isclose(means[N], .21137770478557535)
    independent = pd.read_csv(DATA / "independent_case_results.csv")
    with plt.rc_context(STYLE):
        pair_figure(core)
        component_figure(core, independent)
        external_figure(pd.read_csv(DATA / "independent_family_results.csv"), pd.read_csv(DATA / "independent_macro_results.csv"))
        admission_figure()
    manifest = {"date": "2026-10-19", "python": sys.version, "matplotlib": matplotlib.__version__,
                "input_hashes": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob("*.csv")},
                "outputs": FILES, "no_model_inference": True, "no_new_significance_tests": True,
                "core_aggregate_gain_percent": 100 * (1 - means.TASCA / means[N]),
                "layout": "No in-image figure titles; panel labels and short subtitles below each subplot."}
    (ROOT / "outputs" / "figure_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print("Four result figures generated from archived data: " + str(OUT), flush=True)


if __name__ == "__main__":
    main()
