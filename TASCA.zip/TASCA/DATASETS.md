# Data and offline models

No datasets, learned weights or credentials are redistributed. Supply licensed data from the original providers. `datasets/core_manifest.json` records the exact original bytes (SHA-256), while `engines/core/windows.csv` freezes all pair/target/window definitions without private paths.

Default layout:

```text
models/chronos-2/{config.json,model.safetensors,...}
models/moirai-2.0-r-small/{config.json,model.safetensors,...}
datasets/core/<filename from core_manifest.json>
datasets/independent/<filename from independent_manifest.json>
datasets/synchronized/air_quality/AirQualityUCI.csv
datasets/synchronized/capital_bike/hour.csv
datasets/synchronized/seoul_bike/SeoulBikeData.csv
```

Alternatively make an ignored `local_config.json` containing `model_root`, `independent_data`, `synchronized_data`, and `core_datasets` (a dataset-ID-to-file map). Paths can point to existing offline storage; copying large data is unnecessary. Environment variables `TASCA_MODEL_ROOT`, `TASCA_INDEPENDENT_DATA`, and `TASCA_SYNCHRONIZED_DATA` override corresponding roots.

Core sources: [ETT](https://github.com/zhouhaoyi/ETDataset), [electricity/traffic/exchange-rate/solar benchmark](https://github.com/laiguokun/multivariate-time-series-data), [weather](https://www.bgc-jena.mpg.de/wetter/), [Beijing PM2.5](https://archive.ics.uci.edu/dataset/381/beijing+pm2+5+data). Benchmark CSV conversions vary. A source download with a different encoding, row order, header or preprocessing is **not** automatically equivalent to the frozen file. The runner rejects mismatches; do not edit expected hashes merely to bypass the check. The public repository does not yet include deterministic conversion scripts for every upstream core format, so exact core CSV preparation remains a documented user-supplied prerequisite.

Independent validation uses Appliances, SML2010, Tetouan, HAI normal training data and Beijing multisite. Original download URLs, names and hashes are included in `datasets/independent_manifest.json`. Synchronized sources are UCI Air Quality, Capital Bike and Seoul Bike, with original URLs in the dedicated downloader. Run `download_optional_data.py` once online for these two validation collections; inference never downloads data. Synchronization, missingness and exclusion rules are implemented in each engine's protocol module.

Model sources: [Chronos-2](https://huggingface.co/amazon/chronos-2), [Moirai-2.0-R-small](https://huggingface.co/Salesforce/moirai-2.0-R-small). Download full model snapshots (including configuration files) to the above folders in advance. Check their individual licenses. The runners use local-only loading. Model hashes and software versions are recorded with runs; different model revisions are not promised numerically identical.
